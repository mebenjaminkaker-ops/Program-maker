package com.example.util

import java.util.Calendar
import java.util.Locale

object PersianUtils {

    private val persianDigits = charArrayOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')

    fun toPersianDigits(input: String): String {
        val sb = StringBuilder(input.length)
        for (ch in input) {
            if (ch in '0'..'9') {
                sb.append(persianDigits[ch - '0'])
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun toPersianDigits(number: Number): String = toPersianDigits(number.toString())

    fun formatBytesShort(bytes: Long): String {
        val safeBytes = bytes.coerceAtLeast(0L)
        return when {
            safeBytes >= 1024L * 1024L * 1024L -> {
                val gb = safeBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
                toPersianDigits(String.format(Locale.US, "%.1f GB", gb))
            }
            safeBytes >= 1024L * 1024L -> {
                val mb = safeBytes.toDouble() / (1024.0 * 1024.0)
                val formatted = if (mb >= 10.0) String.format(Locale.US, "%.0f MB", mb) else String.format(Locale.US, "%.1f MB", mb)
                toPersianDigits(formatted)
            }
            safeBytes >= 1024L -> {
                val kb = safeBytes / 1024L
                toPersianDigits("$kb KB")
            }
            else -> toPersianDigits("$safeBytes B")
        }
    }

    fun formatBytesPersianWords(bytes: Long): String {
        val safeBytes = bytes.coerceAtLeast(0L)
        return when {
            safeBytes >= 1024L * 1024L * 1024L -> {
                val gb = safeBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
                toPersianDigits(String.format(Locale.US, "%.2f گیگابایت", gb))
            }
            safeBytes >= 1024L * 1024L -> {
                val mb = safeBytes.toDouble() / (1024.0 * 1024.0)
                val formatted = if (mb >= 10.0) String.format(Locale.US, "%.0f مگابایت", mb) else String.format(Locale.US, "%.1f مگابایت", mb)
                toPersianDigits(formatted)
            }
            safeBytes >= 1024L -> {
                val kb = safeBytes / 1024L
                toPersianDigits("$kb کیلوبایت")
            }
            else -> toPersianDigits("$safeBytes بایت")
        }
    }

    fun formatStoragePair(usedBytes: Long, totalBytes: Long): String {
        val usedGb = usedBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
        val totalGb = totalBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
        val formatted = String.format(Locale.US, "%.1f GB / %.0f GB", usedGb, totalGb)
        return toPersianDigits(formatted)
    }

    /**
     * Converts epoch milliseconds to Persian Shamsi date/time string.
     * Displays "امروز، HH:mm" or "دیروز، HH:mm" for recent entries, otherwise "YYYY/MM/DD، HH:mm".
     */
    fun formatShamsiDateTime(epochMillis: Long, nowMillis: Long = System.currentTimeMillis()): String {
        val targetCal = Calendar.getInstance().apply { timeInMillis = epochMillis }
        val nowCal = Calendar.getInstance().apply { timeInMillis = nowMillis }

        val timeStr = String.format(
            Locale.US,
            "%02d:%02d",
            targetCal.get(Calendar.HOUR_OF_DAY),
            targetCal.get(Calendar.MINUTE),
        )

        val isSameDay = targetCal.get(Calendar.YEAR) == nowCal.get(Calendar.YEAR) &&
            targetCal.get(Calendar.DAY_OF_YEAR) == nowCal.get(Calendar.DAY_OF_YEAR)
        if (isSameDay) {
            return "امروز، ${toPersianDigits(timeStr)}"
        }

        val yesterdayCal = Calendar.getInstance().apply {
            timeInMillis = nowMillis
            add(Calendar.DAY_OF_YEAR, -1)
        }
        val isYesterday = targetCal.get(Calendar.YEAR) == yesterdayCal.get(Calendar.YEAR) &&
            targetCal.get(Calendar.DAY_OF_YEAR) == yesterdayCal.get(Calendar.DAY_OF_YEAR)
        if (isYesterday) {
            return "دیروز، ${toPersianDigits(timeStr)}"
        }

        val (jy, jm, jd) = gregorianToJalali(
            targetCal.get(Calendar.YEAR),
            targetCal.get(Calendar.MONTH) + 1,
            targetCal.get(Calendar.DAY_OF_MONTH),
        )
        val dateStr = String.format(Locale.US, "%04d/%02d/%02d", jy, jm, jd)
        return "${toPersianDigits(dateStr)}، ${toPersianDigits(timeStr)}"
    }

    fun gregorianToJalali(gy: Int, gm: Int, gd: Int): Triple<Int, Int, Int> {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) + ((gy2 + 399) / 400) + gd + gdm[gm - 1]
        var jy = -1595 + (33 * (days / 12053))
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + (days / 31)
            jd = 1 + (days % 31)
        } else {
            jm = 7 + ((days - 186) / 30)
            jd = 1 + ((days - 186) % 30)
        }
        return Triple(jy, jm, jd)
    }
}
