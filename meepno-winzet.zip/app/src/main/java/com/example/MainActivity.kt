package com.example

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.widthIn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.MainTab
import com.example.ui.components.AppHeader
import com.example.ui.components.CyberBackground
import com.example.ui.components.CyberBottomNav
import com.example.ui.components.SafeConfirmModal
import com.example.ui.components.SensitiveSwipeModal
import com.example.ui.components.SuccessOverlay
import com.example.ui.screens.CleanerScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SpaceScreen
import com.example.ui.theme.MeepnoWinzetTheme
import com.example.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent {
            MeepnoWinzetTheme {
                MeepnoWinzetApp()
            }
        }
    }
}

@Composable
fun MeepnoWinzetApp(
    viewModel: MainViewModel = viewModel(),
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
    val storageSummary by viewModel.storageSummary.collectAsStateWithLifecycle()
    val scanProgress by viewModel.scanProgress.collectAsStateWithLifecycle()
    val tempFiles by viewModel.tempFiles.collectAsStateWithLifecycle()
    val duplicatePhotos by viewModel.duplicatePhotos.collectAsStateWithLifecycle()
    val largeFiles by viewModel.largeFiles.collectAsStateWithLifecycle()
    val historyLogs by viewModel.historyLogs.collectAsStateWithLifecycle()
    val totalFreedHistoryBytes by viewModel.totalFreedHistoryBytes.collectAsStateWithLifecycle()
    val hasAllFilesAccess by viewModel.hasAllFilesAccess.collectAsStateWithLifecycle()
    val hasMediaAccess by viewModel.hasMediaAccess.collectAsStateWithLifecycle()
    val shizukuStatus by viewModel.shizukuStatus.collectAsStateWithLifecycle()
    val shizukuRamEnabled by viewModel.shizukuRamEnabled.collectAsStateWithLifecycle()
    val shizukuApps by viewModel.shizukuApps.collectAsStateWithLifecycle()
    val shizukuMessage by viewModel.shizukuMessage.collectAsStateWithLifecycle()
    val showSafeConfirmDialog by viewModel.showSafeConfirmDialog.collectAsStateWithLifecycle()
    val showSensitiveConfirmDialog by viewModel.showSensitiveConfirmDialog.collectAsStateWithLifecycle()
    val cleanupSuccessSummary by viewModel.cleanupSuccessSummary.collectAsStateWithLifecycle()
    val pendingMediaDeleteUris by viewModel.pendingMediaDeleteUris.collectAsStateWithLifecycle()

    // Refresh permissions & storage stats every time the user returns to the app
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshEnvironmentAndStorage()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Back navigation across custom tabs
    BackHandler(enabled = activeTab != MainTab.DASHBOARD && cleanupSuccessSummary == null) {
        viewModel.selectTab(MainTab.DASHBOARD)
    }

    val mediaPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions(),
    ) {
        viewModel.refreshEnvironmentAndStorage()
    }

    val mediaDeleteSenderLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult(),
    ) { result ->
        viewModel.onMediaStoreDeleteResult(result.resultCode == Activity.RESULT_OK)
    }

    // Trigger Android's official MediaStore delete confirmation when Scoped Storage blocks direct File.delete()
    LaunchedEffect(pendingMediaDeleteUris) {
        val uris = pendingMediaDeleteUris
        if (!uris.isNullOrEmpty() && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val pendingIntent = MediaStore.createDeleteRequest(context.contentResolver, uris)
                val request = IntentSenderRequest.Builder(pendingIntent.intentSender).build()
                mediaDeleteSenderLauncher.launch(request)
            } catch (_: Exception) {
                viewModel.onMediaStoreDeleteResult(false)
            }
        }
    }

    fun requestStoragePermissions() {
        val runtimePerms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
            )
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        } else {
            arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
            )
        }
        mediaPermissionLauncher.launch(runtimePerms)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            val intent = Intent(
                Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:${context.packageName}"),
            )
            runCatching {
                context.startActivity(intent)
            }.onFailure {
                runCatching {
                    context.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
            }
        }
    }

    fun openUsageAccessSettings() {
        runCatching {
            val intent = Intent(
                Settings.ACTION_USAGE_ACCESS_SETTINGS,
                Uri.parse("package:${context.packageName}"),
            )
            context.startActivity(intent)
        }.onFailure {
            runCatching {
                context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }
        }
    }

    val effectiveFileAccess = hasAllFilesAccess || hasMediaAccess

    CyberBackground {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.TopCenter,
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 520.dp)
                    .fillMaxSize(),
            ) {
                AppHeader(
                    onSettingsClick = { viewModel.selectTab(MainTab.SETTINGS) },
                )

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                ) {
                    Crossfade(
                        targetState = activeTab,
                        animationSpec = tween(220),
                        label = "tab_crossfade",
                    ) { tab ->
                        when (tab) {
                            MainTab.DASHBOARD -> DashboardScreen(
                                storageSummary = storageSummary,
                                hasScanned = scanProgress.hasScanned,
                                tempBytes = tempFiles.sumOf { it.sizeBytes },
                                duplicateCount = duplicatePhotos.size,
                                largeFilesCount = largeFiles.size,
                                onQuickTempClick = { viewModel.selectTab(MainTab.CLEANER) },
                                onQuickDuplicatesClick = { viewModel.selectTab(MainTab.CLEANER) },
                                onQuickLargeFilesClick = { viewModel.selectTab(MainTab.SPACE) },
                                onSmartScanClick = { viewModel.startSmartScan() },
                            )

                            MainTab.CLEANER -> CleanerScreen(
                                scanProgress = scanProgress,
                                tempFiles = tempFiles,
                                duplicatePhotos = duplicatePhotos,
                                largeFiles = largeFiles,
                                hasFilePermission = effectiveFileAccess,
                                onStartScan = { viewModel.startSmartScan() },
                                onToggleTemp = { viewModel.toggleTempItem(it) },
                                onToggleDuplicate = { viewModel.toggleDuplicateItem(it) },
                                onToggleLarge = { viewModel.toggleLargeItem(it) },
                                onCleanSelected = { viewModel.requestCleanConfirmation() },
                                onRequestPermission = { requestStoragePermissions() },
                            )

                            MainTab.SPACE -> SpaceScreen(
                                storageSummary = storageSummary,
                                largeFiles = largeFiles,
                                onRefresh = { viewModel.refreshEnvironmentAndStorage() },
                                onOpenUsageAccessSettings = { openUsageAccessSettings() },
                                onDeleteLargeFile = { viewModel.selectLargeFileForCleanup(it) },
                            )

                            MainTab.HISTORY -> HistoryScreen(
                                logs = historyLogs,
                                totalFreedBytes = totalFreedHistoryBytes,
                                onClearHistory = { viewModel.clearHistory() },
                            )

                            MainTab.SETTINGS -> SettingsScreen(
                                hasFileAccess = effectiveFileAccess,
                                hasUsageStatsAccess = storageSummary.hasUsageStatsPermission,
                                shizukuStatus = shizukuStatus,
                                shizukuRamEnabled = shizukuRamEnabled,
                                shizukuApps = shizukuApps,
                                shizukuMessage = shizukuMessage,
                                onToggleFileAccess = { requestStoragePermissions() },
                                onToggleShizuku = { viewModel.toggleShizukuRamAccess() },
                                onOpenShizukuApp = { viewModel.openShizukuApp() },
                                onForceStopPackage = { viewModel.forceStopPackage(it) },
                                onForceStopAll = { viewModel.forceStopAllBackgroundPackages() },
                                onToggleUsageStats = { openUsageAccessSettings() },
                            )
                        }
                    }
                }

                CyberBottomNav(
                    activeTab = activeTab,
                    onSelectTab = { viewModel.selectTab(it) },
                )
            }
        }

        SafeConfirmModal(
            visible = showSafeConfirmDialog,
            onDismiss = { viewModel.dismissConfirmDialogs() },
            onConfirm = { viewModel.executeClean(isSensitive = false) },
        )

        SensitiveSwipeModal(
            visible = showSensitiveConfirmDialog,
            onDismiss = { viewModel.dismissConfirmDialogs() },
            onSwipeConfirmed = { viewModel.executeClean(isSensitive = true) },
        )

        SuccessOverlay(
            summary = cleanupSuccessSummary,
            onDismiss = { viewModel.closeSuccessOverlay() },
        )
    }
}
