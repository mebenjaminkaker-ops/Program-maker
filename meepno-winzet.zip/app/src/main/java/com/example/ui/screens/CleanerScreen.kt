package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.VideoFile
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.data.model.DuplicatePhotoItem
import com.example.data.model.LargeFileItem
import com.example.data.model.ScanProgressState
import com.example.data.model.TempFileItem
import com.example.ui.components.GlassPanel
import com.example.ui.theme.GlassCardBg
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.PersianUtils
import java.io.File

@Composable
fun CleanerScreen(
    scanProgress: ScanProgressState,
    tempFiles: List<TempFileItem>,
    duplicatePhotos: List<DuplicatePhotoItem>,
    largeFiles: List<LargeFileItem>,
    hasFilePermission: Boolean,
    onStartScan: () -> Unit,
    onToggleTemp: (String) -> Unit,
    onToggleDuplicate: (String) -> Unit,
    onToggleLarge: (String) -> Unit,
    onCleanSelected: () -> Unit,
    onRequestPermission: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
    ) {
        if (!hasFilePermission && !scanProgress.isScanning) {
            GlassPanel(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                borderColor = NeonPurple.copy(alpha = 0.4f),
                contentPadding = PaddingValues(12.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = stringResource(R.string.cleaner_permission_needed),
                        fontSize = 11.sp,
                        color = TextPrimary,
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 8.dp),
                    )
                    Button(
                        onClick = onRequestPermission,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonPurple,
                            contentColor = Color.White,
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("cleaner_grant_permission_btn"),
                    ) {
                        Text(
                            text = stringResource(R.string.cleaner_grant_permission),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
        }

        when {
            scanProgress.isScanning -> {
                ScanningProgressSection(scanProgress = scanProgress)
            }

            !scanProgress.hasScanned -> {
                InitialScanSection(onStartScan = onStartScan)
            }

            else -> {
                ScanResultsSection(
                    tempFiles = tempFiles,
                    duplicatePhotos = duplicatePhotos,
                    largeFiles = largeFiles,
                    onToggleTemp = onToggleTemp,
                    onToggleDuplicate = onToggleDuplicate,
                    onToggleLarge = onToggleLarge,
                    onCleanSelected = onCleanSelected,
                    onRescan = onStartScan,
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}

@Composable
private fun InitialScanSection(onStartScan: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 44.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(124.dp)
                .shadow(
                    elevation = 24.dp,
                    shape = CircleShape,
                    ambientColor = NeonCyan.copy(alpha = 0.4f),
                    spotColor = NeonCyan.copy(alpha = 0.4f),
                )
                .clip(CircleShape)
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(NeonCyan, NeonPurple),
                    ),
                )
                .clickable(onClick = onStartScan)
                .testTag("cleaner_start_scan_circle"),
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Outlined.Search,
                    contentDescription = stringResource(R.string.cleaner_start_scan),
                    tint = Color.Black,
                    modifier = Modifier.size(32.dp),
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = stringResource(R.string.cleaner_start_scan),
                    color = Color.Black,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold,
                )
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = stringResource(R.string.cleaner_ready_subtitle),
            fontSize = 12.sp,
            color = TextSecondary,
        )
    }
}

@Composable
private fun ScanningProgressSection(scanProgress: ScanProgressState) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text(
            text = stringResource(R.string.cleaner_scanning_title),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
        )

        ScanStepRow(
            label = stringResource(R.string.cleaner_step_temp),
            progress = scanProgress.step1TempProgress,
            isActive = scanProgress.step1Active,
            isDone = scanProgress.step1Done,
        )
        ScanStepRow(
            label = stringResource(R.string.cleaner_step_large),
            progress = scanProgress.step2LargeProgress,
            isActive = scanProgress.step2Active,
            isDone = scanProgress.step2Done,
        )
        ScanStepRow(
            label = stringResource(R.string.cleaner_step_duplicates),
            progress = scanProgress.step3DupProgress,
            isActive = scanProgress.step3Active,
            isDone = scanProgress.step3Done,
        )
    }
}

@Composable
private fun ScanStepRow(
    label: String,
    progress: Float,
    isActive: Boolean,
    isDone: Boolean,
) {
    val animatedFill by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(350),
        label = "step_fill",
    )
    val labelColor by animateColorAsState(
        targetValue = when {
            isActive -> NeonCyan
            isDone -> TextPrimary
            else -> TextSecondary
        },
        label = "step_color",
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = labelColor,
            fontWeight = if (isActive || isDone) FontWeight.SemiBold else FontWeight.Normal,
            modifier = Modifier.width(105.dp),
        )
        Box(
            modifier = Modifier
                .weight(1f)
                .height(4.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color.White.copy(alpha = 0.1f)),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(animatedFill)
                    .shadow(
                        elevation = 6.dp,
                        shape = RoundedCornerShape(10.dp),
                        ambientColor = NeonCyan,
                        spotColor = NeonCyan,
                    )
                    .clip(RoundedCornerShape(10.dp))
                    .background(NeonCyan),
            )
        }
    }
}

@Composable
private fun ScanResultsSection(
    tempFiles: List<TempFileItem>,
    duplicatePhotos: List<DuplicatePhotoItem>,
    largeFiles: List<LargeFileItem>,
    onToggleTemp: (String) -> Unit,
    onToggleDuplicate: (String) -> Unit,
    onToggleLarge: (String) -> Unit,
    onCleanSelected: () -> Unit,
    onRescan: () -> Unit,
) {
    val selectedCount =
        tempFiles.count { it.isSelected } +
            duplicatePhotos.count { it.isSelected } +
            largeFiles.count { it.isSelected }

    if (tempFiles.isEmpty() && duplicatePhotos.isEmpty() && largeFiles.isEmpty()) {
        GlassPanel(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(20.dp),
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Icon(
                    imageVector = Icons.Rounded.Check,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(36.dp),
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = stringResource(R.string.cleaner_no_junk_found),
                    fontSize = 13.sp,
                    color = TextPrimary,
                    textAlign = TextAlign.Center,
                )
                Spacer(modifier = Modifier.height(14.dp))
                OutlinedButton(
                    onClick = onRescan,
                    border = BorderStroke(1.dp, NeonCyan),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("cleaner_rescan_empty_btn"),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Refresh,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(16.dp),
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.cleaner_rescan),
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
        return
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // 1. Temp files (Safe)
        if (tempFiles.isNotEmpty()) {
            val tempTotal = tempFiles.sumOf { it.sizeBytes }
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = GlassCardBg,
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.06f)),
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.DeleteOutline,
                                contentDescription = null,
                                tint = TextPrimary,
                                modifier = Modifier.size(16.dp),
                            )
                            Text(
                                text = stringResource(R.string.cleaner_step_temp),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                            )
                        }
                        Text(
                            text = PersianUtils.formatBytesShort(tempTotal),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = NeonCyan,
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    tempFiles.forEachIndexed { idx, item ->
                        SelectableFileRow(
                            title = item.name,
                            sizeText = PersianUtils.formatBytesShort(item.sizeBytes),
                            selected = item.isSelected,
                            accentColor = NeonCyan,
                            testTag = "temp_item_${item.id}",
                            onClick = { onToggleTemp(item.id) },
                        )
                        if (idx < tempFiles.lastIndex) {
                            HorizontalDivider(color = Color.White.copy(alpha = 0.05f))
                        }
                    }
                }
            }
        }

        // 2. Duplicate photos (Sensitive visual gallery)
        if (duplicatePhotos.isNotEmpty()) {
            val dupTotal = duplicatePhotos.sumOf { it.sizeBytes }
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = GlassCardBg,
                border = BorderStroke(1.dp, NeonRed.copy(alpha = 0.35f)),
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.WarningAmber,
                                contentDescription = null,
                                tint = NeonRed,
                                modifier = Modifier.size(16.dp),
                            )
                            Text(
                                text = stringResource(R.string.cleaner_duplicate_photos),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeonRed,
                            )
                        }
                        Text(
                            text = PersianUtils.formatBytesShort(dupTotal),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = NeonRed,
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(vertical = 4.dp),
                    ) {
                        items(duplicatePhotos, key = { it.id }) { dup ->
                            DuplicateThumbnailCard(
                                item = dup,
                                onClick = { onToggleDuplicate(dup.id) },
                            )
                        }
                    }
                }
            }
        }

        // 3. Large files (>100 MB) if found
        if (largeFiles.isNotEmpty()) {
            val largeTotal = largeFiles.sumOf { it.sizeBytes }
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = GlassCardBg,
                border = BorderStroke(1.dp, NeonMagenta.copy(alpha = 0.3f)),
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.VideoFile,
                                contentDescription = null,
                                tint = NeonMagenta,
                                modifier = Modifier.size(16.dp),
                            )
                            Text(
                                text = stringResource(R.string.cleaner_large_files_section),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                            )
                        }
                        Text(
                            text = PersianUtils.formatBytesShort(largeTotal),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = NeonMagenta,
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    largeFiles.forEachIndexed { idx, item ->
                        SelectableFileRow(
                            title = item.name,
                            sizeText = PersianUtils.formatBytesShort(item.sizeBytes),
                            selected = item.isSelected,
                            accentColor = NeonMagenta,
                            testTag = "large_item_${item.id}",
                            onClick = { onToggleLarge(item.id) },
                        )
                        if (idx < largeFiles.lastIndex) {
                            HorizontalDivider(color = Color.White.copy(alpha = 0.05f))
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        if (selectedCount > 0) {
            Button(
                onClick = onCleanSelected,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .shadow(
                        elevation = 16.dp,
                        shape = RoundedCornerShape(14.dp),
                        ambientColor = NeonCyan.copy(alpha = 0.4f),
                        spotColor = NeonCyan.copy(alpha = 0.4f),
                    )
                    .testTag("cleaner_execute_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonCyan,
                    contentColor = Color.Black,
                ),
            ) {
                Text(
                    text = stringResource(
                        R.string.cleaner_clean_selected,
                        PersianUtils.toPersianDigits(selectedCount),
                    ),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.ExtraBold,
                )
            }
        } else {
            OutlinedButton(
                onClick = onRescan,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("cleaner_rescan_btn"),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.14f)),
            ) {
                Text(
                    text = stringResource(R.string.cleaner_rescan),
                    color = TextSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }
    }
}

@Composable
private fun SelectableFileRow(
    title: String,
    sizeText: String,
    selected: Boolean,
    accentColor: Color,
    testTag: String,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(
            modifier = Modifier
                .weight(1f)
                .padding(end = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(if (selected) accentColor else Color.Transparent)
                    .border(
                        width = 1.5.dp,
                        color = if (selected) accentColor else Color.White.copy(alpha = 0.25f),
                        shape = CircleShape,
                    ),
                contentAlignment = Alignment.Center,
            ) {
                if (selected) {
                    Icon(
                        imageVector = Icons.Rounded.Check,
                        contentDescription = stringResource(R.string.cd_checked),
                        tint = Color.Black,
                        modifier = Modifier.size(12.dp),
                    )
                }
            }

            Text(
                text = title,
                fontSize = 12.sp,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }

        Text(
            text = sizeText,
            fontSize = 12.sp,
            color = TextSecondary,
            fontWeight = FontWeight.Medium,
        )
    }
}

@Composable
private fun DuplicateThumbnailCard(
    item: DuplicatePhotoItem,
    onClick: () -> Unit,
) {
    val context = LocalContext.current
    val imageModel = if (item.path.isNotBlank() && File(item.path).exists()) {
        File(item.path)
    } else {
        item.uriString
    }

    Column(
        modifier = Modifier
            .width(74.dp)
            .minimumInteractiveComponentSize()
            .clickable(onClick = onClick)
            .testTag("dup_thumb_${item.id}"),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(70.dp)
                .then(
                    if (item.isSelected) {
                        Modifier.shadow(
                            elevation = 10.dp,
                            shape = RoundedCornerShape(12.dp),
                            ambientColor = NeonRed,
                            spotColor = NeonRed,
                        )
                    } else {
                        Modifier
                    },
                )
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF1F1F2E))
                .border(
                    width = 2.dp,
                    color = if (item.isSelected) NeonRed else Color.Transparent,
                    shape = RoundedCornerShape(12.dp),
                ),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Outlined.Image,
                contentDescription = null,
                tint = Color(0xFF666677),
                modifier = Modifier.size(24.dp),
            )
            AsyncImage(
                model = ImageRequest.Builder(context)
                    .data(imageModel)
                    .crossfade(true)
                    .size(160)
                    .build(),
                contentDescription = stringResource(R.string.cd_duplicate_thumb, item.name),
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
            if (item.isSelected) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(NeonRed),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Check,
                        contentDescription = stringResource(R.string.cd_checked),
                        tint = Color.White,
                        modifier = Modifier.size(11.dp),
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = item.name,
            fontSize = 9.sp,
            color = if (item.isSelected) NeonRed else TextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
        )
    }
}
