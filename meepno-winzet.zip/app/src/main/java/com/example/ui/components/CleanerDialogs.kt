package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.data.model.CleanupResultSummary
import com.example.ui.theme.GlassBg
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonRed
import com.example.ui.theme.SuccessBgTop
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VazirmatnFontFamily
import com.example.util.PersianUtils
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun SafeConfirmModal(
    visible: Boolean,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
) {
    if (!visible) return

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.78f))
                .clickable(onClick = onDismiss),
            contentAlignment = Alignment.Center,
        ) {
            Surface(
                modifier = Modifier
                    .padding(horizontal = 24.dp)
                    .widthIn(max = 340.dp)
                    .fillMaxWidth()
                    .clickable(enabled = false) {},
                shape = RoundedCornerShape(20.dp),
                color = GlassBg,
                border = BorderStroke(1.dp, GlassBorder),
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Shield,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(44.dp),
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = stringResource(R.string.modal_safe_title),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = stringResource(R.string.modal_safe_desc),
                        fontSize = 12.sp,
                        color = TextSecondary,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("modal_safe_cancel"),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.14f)),
                        ) {
                            Text(
                                text = stringResource(R.string.modal_cancel),
                                color = TextPrimary,
                                fontWeight = FontWeight.SemiBold,
                            )
                        }
                        Button(
                            onClick = onConfirm,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("modal_safe_confirm"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NeonCyan,
                                contentColor = Color.Black,
                            ),
                        ) {
                            Text(
                                text = stringResource(R.string.modal_confirm),
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SensitiveSwipeModal(
    visible: Boolean,
    onDismiss: () -> Unit,
    onSwipeConfirmed: () -> Unit,
) {
    if (!visible) return

    val haptics = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.85f))
                .clickable(onClick = onDismiss),
            contentAlignment = Alignment.Center,
        ) {
            Surface(
                modifier = Modifier
                    .padding(horizontal = 24.dp)
                    .widthIn(max = 340.dp)
                    .fillMaxWidth()
                    .shadow(
                        elevation = 24.dp,
                        shape = RoundedCornerShape(20.dp),
                        ambientColor = NeonRed.copy(alpha = 0.25f),
                        spotColor = NeonRed.copy(alpha = 0.25f),
                    )
                    .clickable(enabled = false) {},
                shape = RoundedCornerShape(20.dp),
                color = GlassBg,
                border = BorderStroke(1.5.dp, NeonRed),
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.WarningAmber,
                        contentDescription = null,
                        tint = NeonRed,
                        modifier = Modifier.size(44.dp),
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = stringResource(R.string.modal_sensitive_title),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonRed,
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = stringResource(R.string.modal_sensitive_desc),
                        fontSize = 12.sp,
                        color = TextSecondary,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(modifier = Modifier.height(20.dp))

                    // Interactive RTL swipe-to-left track ("برای تأیید به چپ بکشید")
                    BoxWithConstraints(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .clip(RoundedCornerShape(26.dp))
                            .background(Color.White.copy(alpha = 0.1f))
                            .border(1.dp, NeonRed.copy(alpha = 0.35f), RoundedCornerShape(26.dp))
                            .testTag("swipe_confirm_track"),
                        contentAlignment = Alignment.Center,
                    ) {
                        val thumbSizePx = with(density) { 44.dp.toPx() }
                        val horizontalPaddingPx = with(density) { 4.dp.toPx() }
                        val maxTravelPx = (constraints.maxWidth - thumbSizePx - horizontalPaddingPx * 2f).coerceAtLeast(1f)
                        val offsetAnim = remember { Animatable(0f) }
                        var triggered by remember { mutableFloatStateOf(0f) }

                        Text(
                            text = stringResource(R.string.modal_swipe_to_confirm),
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.55f),
                        )

                        // In RTL, Alignment.CenterStart is the RIGHT edge; dragging left decreases X (negative delta)
                        Box(
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .padding(start = 4.dp)
                                .offset { IntOffset(offsetAnim.value.roundToInt(), 0) }
                                .size(44.dp)
                                .shadow(
                                    elevation = 14.dp,
                                    shape = CircleShape,
                                    ambientColor = NeonRed,
                                    spotColor = NeonRed,
                                )
                                .clip(CircleShape)
                                .background(NeonRed)
                                .pointerInput(maxTravelPx) {
                                    detectHorizontalDragGestures(
                                        onDragEnd = {
                                            if (triggered == 0f) {
                                                scope.launch {
                                                    offsetAnim.animateTo(
                                                        0f,
                                                        spring(stiffness = Spring.StiffnessMedium),
                                                    )
                                                }
                                            }
                                        },
                                        onDragCancel = {
                                            if (triggered == 0f) {
                                                scope.launch { offsetAnim.animateTo(0f) }
                                            }
                                        },
                                        onHorizontalDrag = { change, dragAmount ->
                                            change.consume()
                                            if (triggered != 0f) return@detectHorizontalDragGestures
                                            // Moving leftward produces negative dragAmount
                                            val next = (offsetAnim.value + dragAmount).coerceIn(-maxTravelPx, 0f)
                                            scope.launch { offsetAnim.snapTo(next) }
                                            if (-next >= maxTravelPx * 0.68f) {
                                                triggered = 1f
                                                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                                onSwipeConfirmed()
                                            }
                                        },
                                    )
                                }
                                .testTag("swipe_confirm_thumb"),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowLeft,
                                contentDescription = stringResource(R.string.cd_swipe_arrow),
                                tint = Color.Black,
                                modifier = Modifier.size(22.dp),
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("modal_sensitive_dismiss"),
                    ) {
                        Text(
                            text = stringResource(R.string.modal_dismiss),
                            color = TextSecondary,
                            fontSize = 13.sp,
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SuccessOverlay(
    summary: CleanupResultSummary?,
    onDismiss: () -> Unit,
) {
    AnimatedVisibility(
        visible = summary != null,
        enter = fadeIn(tween(350)),
        exit = fadeOut(tween(250)),
    ) {
        if (summary != null) {
            val useKb = summary.freedBytes in 1L until (1024L * 1024L)
            val targetValue = if (useKb) {
                (summary.freedBytes / 1024L).toInt()
            } else {
                (summary.freedBytes / (1024.0 * 1024.0)).roundToInt()
            }
            val unitLabel = if (useKb) "KB" else "MB"

            val animatedVal by animateFloatAsState(
                targetValue = targetValue.toFloat(),
                animationSpec = tween(durationMillis = 900, easing = FastOutSlowInEasing),
                label = "success_counter",
            )
            val iconScale = remember { Animatable(0.4f) }
            LaunchedEffect(summary) {
                iconScale.animateTo(
                    1f,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessLow,
                    ),
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(SuccessBgTop, Color.Black),
                            center = Offset(500f, 350f),
                            radius = 1200f,
                        ),
                    )
                    .clickable(enabled = false) {}
                    .padding(24.dp),
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(
                        modifier = Modifier
                            .scale(iconScale.value)
                            .size(92.dp)
                            .shadow(
                                elevation = 28.dp,
                                shape = CircleShape,
                                ambientColor = NeonCyan.copy(alpha = 0.45f),
                                spotColor = NeonCyan.copy(alpha = 0.45f),
                            )
                            .clip(CircleShape)
                            .border(3.dp, NeonCyan, CircleShape),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Check,
                            contentDescription = stringResource(R.string.cd_success_check),
                            tint = NeonCyan,
                            modifier = Modifier.size(46.dp),
                        )
                    }

                    Spacer(modifier = Modifier.height(22.dp))
                    Text(
                        text = stringResource(R.string.success_title),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextPrimary,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.Center,
                    ) {
                        Text(
                            text = PersianUtils.toPersianDigits(animatedVal.roundToInt()),
                            style = TextStyle(
                                fontFamily = VazirmatnFontFamily,
                                fontSize = 54.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = NeonCyan,
                                shadow = Shadow(
                                    color = NeonCyan.copy(alpha = 0.5f),
                                    blurRadius = 24f,
                                ),
                            ),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = unitLabel,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(bottom = 10.dp),
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = stringResource(R.string.success_freed_label),
                        fontSize = 13.sp,
                        color = TextPrimary,
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = stringResource(
                            R.string.success_files_deleted,
                            PersianUtils.toPersianDigits(summary.deletedFilesCount),
                        ),
                        fontSize = 11.sp,
                        color = TextSecondary,
                    )
                    Spacer(modifier = Modifier.height(26.dp))

                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("success_got_it_button"),
                        shape = RoundedCornerShape(22.dp),
                        border = BorderStroke(1.dp, NeonCyan),
                    ) {
                        Text(
                            text = stringResource(R.string.success_got_it),
                            color = NeonCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            modifier = Modifier.padding(horizontal = 18.dp),
                        )
                    }
                }
            }
        }
    }
}
