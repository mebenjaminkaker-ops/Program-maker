package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val CyberDarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = Color.Black,
    secondary = NeonPurple,
    onSecondary = Color.White,
    tertiary = NeonMagenta,
    onTertiary = Color.White,
    background = BgDark,
    onBackground = TextPrimary,
    surface = GlassBg,
    onSurface = TextPrimary,
    surfaceVariant = Color(0xFF141422),
    onSurfaceVariant = TextSecondary,
    error = NeonRed,
    onError = Color.White,
    outline = GlassBorder,
)

@Composable
fun MeepnoWinzetTheme(
    content: @Composable () -> Unit,
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = CyberDarkColorScheme,
            typography = Typography,
            content = content,
        )
    }
}
