package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.LargeFileItem
import com.example.data.model.StorageSummary
import com.example.ui.components.GlassPanel
import com.example.ui.theme.GlassCardBg
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TrackBg
import com.example.util.PersianUtils
import kotlin.math.max

@Composable
fun SpaceScreen(
    storageSummary: StorageSummary,
    largeFiles: List<LargeFileItem>,
    onRefresh: () -> Unit,
    onOpenUsageAccessSettings: () -> Unit,
    onDeleteLargeFile: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val maxCategoryBytes = max(
        1L,
        max(
            storageSummary.videosBytes,
            max(storageSummary.imagesBytes, storageSummary.appsBytes),
        ),
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
    ) {
        GlassPanel(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = stringResource(R.string.space_analysis_title),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                    )
                    IconButton(
                        onClick = onRefresh,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("space_refresh_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Refresh,
                            contentDescription = stringResource(R.string.space_refresh),
                            tint = NeonCyan,
                            modifier = Modifier.size(18.dp),
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                StorageCategoryBar(
                    label = stringResource(R.string.space_videos),
                    sizeBytes = storageSummary.videosBytes,
                    ratio = storageSummary.videosBytes.toFloat() / maxCategoryBytes.toFloat(),
                    fillColor = NeonPurple,
                )
                Spacer(modifier = Modifier.height(14.dp))

                StorageCategoryBar(
                    label = stringResource(R.string.space_images),
                    sizeBytes = storageSummary.imagesBytes,
                    ratio = storageSummary.imagesBytes.toFloat() / maxCategoryBytes.toFloat(),
                    fillColor = NeonCyan,
                )
                Spacer(modifier = Modifier.height(14.dp))

                StorageCategoryBar(
                    label = stringResource(R.string.space_apps),
                    sizeBytes = storageSummary.appsBytes,
                    ratio = storageSummary.appsBytes.toFloat() / maxCategoryBytes.toFloat(),
                    fillColor = NeonMagenta,
                )

                if (!storageSummary.hasUsageStatsPermission) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.04f))
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            text = stringResource(R.string.space_usage_access_hint),
                            fontSize = 10.sp,
                            color = TextSecondary,
                            modifier = Modifier
                                .weight(1f)
                                .padding(end = 8.dp),
                        )
                        Button(
                            onClick = onOpenUsageAccessSettings,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NeonMagenta,
                                contentColor = Color.White,
                            ),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("space_usage_access_button"),
                        ) {
                            Text(
                                text = stringResource(R.string.space_usage_access_btn),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = stringResource(R.string.space_large_files),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
        Spacer(modifier = Modifier.height(10.dp))

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = GlassCardBg,
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.06f)),
        ) {
            if (largeFiles.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = stringResource(R.string.space_no_large_files),
                        fontSize = 12.sp,
                        color = TextSecondary,
                    )
                }
            } else {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                    largeFiles.forEachIndexed { idx, file ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .clickable { onDeleteLargeFile(file.id) }
                                .padding(vertical = 8.dp)
                                .testTag("space_large_item_${file.id}"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text(
                                text = file.name,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(end = 8.dp),
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = PersianUtils.formatBytesShort(file.sizeBytes),
                                    fontSize = 12.sp,
                                    color = NeonMagenta,
                                    fontWeight = FontWeight.SemiBold,
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Outlined.DeleteOutline,
                                    contentDescription = stringResource(R.string.modal_safe_title),
                                    tint = NeonRed.copy(alpha = 0.85f),
                                    modifier = Modifier.size(16.dp),
                                )
                            }
                        }
                        if (idx < largeFiles.lastIndex) {
                            HorizontalDivider(color = Color.White.copy(alpha = 0.05f))
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}

@Composable
private fun StorageCategoryBar(
    label: String,
    sizeBytes: Long,
    ratio: Float,
    fillColor: Color,
) {
    val animatedRatio by animateFloatAsState(
        targetValue = if (sizeBytes > 0L) ratio.coerceIn(0.04f, 1f) else 0f,
        animationSpec = tween(durationMillis = 700, easing = FastOutSlowInEasing),
        label = "cat_bar",
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = label,
                fontSize = 12.sp,
                color = TextPrimary,
            )
            Text(
                text = PersianUtils.formatBytesShort(sizeBytes),
                fontSize = 12.sp,
                color = TextPrimary,
                fontWeight = FontWeight.SemiBold,
            )
        }
        Spacer(modifier = Modifier.height(5.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(TrackBg),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(animatedRatio)
                    .shadow(
                        elevation = 8.dp,
                        shape = RoundedCornerShape(10.dp),
                        ambientColor = fillColor,
                        spotColor = fillColor,
                    )
                    .clip(RoundedCornerShape(10.dp))
                    .background(fillColor),
            )
        }
    }
}
