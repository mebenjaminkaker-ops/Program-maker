package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.FileCopy
import androidx.compose.material.icons.outlined.VideoFile
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.StorageSummary
import com.example.ui.components.GlassPanel
import com.example.ui.components.NeonGradientButton
import com.example.ui.theme.GlassCardBg
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TrackBg
import com.example.ui.theme.VazirmatnFontFamily
import com.example.util.PersianUtils

@Composable
fun DashboardScreen(
    storageSummary: StorageSummary,
    hasScanned: Boolean,
    tempBytes: Long,
    duplicateCount: Int,
    largeFilesCount: Int,
    onQuickTempClick: () -> Unit,
    onQuickDuplicatesClick: () -> Unit,
    onQuickLargeFilesClick: () -> Unit,
    onSmartScanClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val animatedPercent by animateFloatAsState(
        targetValue = storageSummary.usedPercent.toFloat() / 100f,
        animationSpec = tween(durationMillis = 900, easing = FastOutSlowInEasing),
        label = "gauge_sweep",
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
    ) {
        // Storage Gauge Glass Card
        GlassPanel(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(
                    modifier = Modifier.size(134.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val strokeWidth = 10.dp.toPx()
                        drawArc(
                            color = Color.White.copy(alpha = 0.06f),
                            startAngle = 0f,
                            sweepAngle = 360f,
                            useCenter = false,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
                        )
                        drawArc(
                            brush = Brush.linearGradient(
                                colors = listOf(NeonCyan, NeonPurple, NeonMagenta),
                            ),
                            startAngle = -90f,
                            sweepAngle = 360f * animatedPercent.coerceIn(0f, 1f),
                            useCenter = false,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = PersianUtils.toPersianDigits(storageSummary.usedPercent),
                                style = TextStyle(
                                    fontFamily = VazirmatnFontFamily,
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = TextPrimary,
                                    shadow = Shadow(
                                        color = NeonCyan.copy(alpha = 0.45f),
                                        offset = Offset.Zero,
                                        blurRadius = 18f,
                                    ),
                                ),
                            )
                            Text(
                                text = "%",
                                fontSize = 12.sp,
                                color = TextSecondary,
                                modifier = Modifier.padding(bottom = 5.dp, start = 2.dp),
                            )
                        }
                        Text(
                            text = stringResource(R.string.dashboard_memory_in_use),
                            fontSize = 10.sp,
                            color = TextSecondary,
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Mini storage progress bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = stringResource(R.string.dashboard_storage_space),
                        fontSize = 11.sp,
                        color = TextSecondary,
                    )
                    Text(
                        text = if (storageSummary.totalBytes > 0L) {
                            PersianUtils.formatStoragePair(
                                storageSummary.usedBytes,
                                storageSummary.totalBytes,
                            )
                        } else {
                            "—"
                        },
                        fontSize = 11.sp,
                        color = TextSecondary,
                    )
                }
                Spacer(modifier = Modifier.height(5.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(TrackBg),
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(animatedPercent.coerceIn(0.02f, 1f))
                            .shadow(
                                elevation = 8.dp,
                                shape = RoundedCornerShape(10.dp),
                                ambientColor = NeonCyan,
                                spotColor = NeonCyan,
                            )
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                brush = Brush.horizontalGradient(
                                    colors = listOf(NeonCyan, NeonPurple),
                                ),
                            ),
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = stringResource(R.string.dashboard_quick_access),
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            QuickAccessCard(
                title = stringResource(R.string.dashboard_temp_files),
                badge = if (hasScanned) {
                    PersianUtils.formatBytesShort(tempBytes)
                } else {
                    stringResource(R.string.dashboard_ready_scan)
                },
                icon = Icons.Outlined.Delete,
                accentColor = NeonCyan,
                badgeColor = NeonRed,
                testTag = "qa_temp_card",
                onClick = onQuickTempClick,
                modifier = Modifier.weight(1f),
            )
            QuickAccessCard(
                title = stringResource(R.string.dashboard_duplicates),
                badge = if (hasScanned) {
                    stringResource(
                        R.string.dashboard_count_items,
                        PersianUtils.toPersianDigits(duplicateCount),
                    )
                } else {
                    stringResource(R.string.dashboard_ready_scan)
                },
                icon = Icons.Outlined.FileCopy,
                accentColor = NeonPurple,
                badgeColor = NeonPurple,
                testTag = "qa_duplicates_card",
                onClick = onQuickDuplicatesClick,
                modifier = Modifier.weight(1f),
            )
            QuickAccessCard(
                title = stringResource(R.string.dashboard_large_files),
                badge = stringResource(
                    R.string.dashboard_count_files,
                    PersianUtils.toPersianDigits(largeFilesCount),
                ),
                icon = Icons.Outlined.VideoFile,
                accentColor = NeonMagenta,
                badgeColor = NeonMagenta,
                testTag = "qa_large_card",
                onClick = onQuickLargeFilesClick,
                modifier = Modifier.weight(1f),
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        NeonGradientButton(
            text = stringResource(R.string.dashboard_smart_scan),
            icon = Icons.Rounded.Bolt,
            onClick = onSmartScanClick,
            testTag = "dashboard_smart_scan_button",
        )

        Spacer(modifier = Modifier.height(20.dp))
    }
}

@Composable
private fun QuickAccessCard(
    title: String,
    badge: String,
    icon: ImageVector,
    accentColor: Color,
    badgeColor: Color,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(16.dp),
        color = GlassCardBg,
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.06f)),
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(17.dp),
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = badge,
                fontSize = 10.sp,
                fontWeight = FontWeight.ExtraBold,
                color = badgeColor,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}
