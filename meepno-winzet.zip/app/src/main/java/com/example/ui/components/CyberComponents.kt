package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Storage
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.MainTab
import com.example.ui.theme.BgDark
import com.example.ui.theme.BgTopPurple
import com.example.ui.theme.BrandTitleStyle
import com.example.ui.theme.GlassBg
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.NavBarBg
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun CyberBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    val transition = rememberInfiniteTransition(label = "bg_orbs")
    val orb1Offset by transition.animateFloat(
        initialValue = 0f,
        targetValue = 28f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 10000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "orb1",
    )
    val orb2Offset by transition.animateFloat(
        initialValue = 0f,
        targetValue = -24f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 12000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "orb2",
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(BgTopPurple, BgDark),
                    center = Offset(500f, 0f),
                    radius = 1600f,
                ),
            ),
    ) {
        // Floating blurred neon orbs matching the HTML prototype
        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .offset(x = (-40).dp + orb1Offset.dp, y = (-40).dp - (orb1Offset * 0.6f).dp)
                .size(260.dp)
                .blur(90.dp)
                .background(NeonCyan.copy(alpha = 0.14f), CircleShape),
        )
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .offset(x = 60.dp + orb2Offset.dp, y = (-100).dp + orb2Offset.dp)
                .size(240.dp)
                .blur(90.dp)
                .background(NeonPurple.copy(alpha = 0.18f), CircleShape),
        )
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .offset(x = 20.dp, y = 40.dp - (orb1Offset * 0.5f).dp)
                .size(200.dp)
                .blur(85.dp)
                .background(NeonMagenta.copy(alpha = 0.10f), CircleShape),
        )

        content()
    }
}

@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 20.dp,
    borderColor: Color = GlassBorder,
    backgroundColor: Color = GlassBg,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable BoxScope.() -> Unit,
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(cornerRadius),
        color = backgroundColor,
        border = BorderStroke(1.dp, borderColor),
    ) {
        Box(
            modifier = Modifier.padding(contentPadding),
            content = content,
        )
    }
}

@Composable
fun AppHeader(
    onSettingsClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(start = 18.dp, end = 14.dp, top = 16.dp, bottom = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column {
            Text(
                text = stringResource(R.string.app_name),
                style = BrandTitleStyle.copy(
                    shadow = Shadow(
                        color = NeonCyan.copy(alpha = 0.35f),
                        offset = Offset.Zero,
                        blurRadius = 18f,
                    ),
                ),
            )
            Text(
                text = stringResource(R.string.app_subtitle),
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
            )
        }

        Box(
            modifier = Modifier
                .minimumInteractiveComponentSize()
                .size(48.dp)
                .clip(RoundedCornerShape(14.dp))
                .clickable(onClick = onSettingsClick)
                .testTag("header_settings_button"),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(GlassBg)
                    .border(1.dp, GlassBorder, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Outlined.Settings,
                    contentDescription = stringResource(R.string.cd_settings_button),
                    tint = TextPrimary,
                    modifier = Modifier.size(18.dp),
                )
            }
        }
    }
}

@Composable
fun CyberBottomNav(
    activeTab: MainTab,
    onSelectTab: (MainTab) -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = NavBarBg,
        border = BorderStroke(1.dp, GlassBorder),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .height(72.dp)
                .padding(horizontal = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BottomNavItem(
                label = stringResource(R.string.nav_dashboard),
                icon = if (activeTab == MainTab.DASHBOARD) Icons.Rounded.Dashboard else Icons.Outlined.Dashboard,
                selected = activeTab == MainTab.DASHBOARD,
                testTag = "nav_dashboard",
                onClick = { onSelectTab(MainTab.DASHBOARD) },
            )
            BottomNavItem(
                label = stringResource(R.string.nav_cleaner),
                icon = if (activeTab == MainTab.CLEANER) Icons.Rounded.Bolt else Icons.Outlined.Bolt,
                selected = activeTab == MainTab.CLEANER,
                testTag = "nav_cleaner",
                onClick = { onSelectTab(MainTab.CLEANER) },
            )
            BottomNavItem(
                label = stringResource(R.string.nav_space),
                icon = if (activeTab == MainTab.SPACE) Icons.Rounded.Storage else Icons.Outlined.Storage,
                selected = activeTab == MainTab.SPACE,
                testTag = "nav_space",
                onClick = { onSelectTab(MainTab.SPACE) },
            )
            BottomNavItem(
                label = stringResource(R.string.nav_history),
                icon = if (activeTab == MainTab.HISTORY) Icons.Rounded.Schedule else Icons.Outlined.Schedule,
                selected = activeTab == MainTab.HISTORY,
                testTag = "nav_history",
                onClick = { onSelectTab(MainTab.HISTORY) },
            )
            BottomNavItem(
                label = stringResource(R.string.nav_settings),
                icon = if (activeTab == MainTab.SETTINGS) Icons.Rounded.Settings else Icons.Outlined.Settings,
                selected = activeTab == MainTab.SETTINGS,
                testTag = "nav_settings",
                onClick = { onSelectTab(MainTab.SETTINGS) },
            )
        }
    }
}

@Composable
private fun BottomNavItem(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    testTag: String,
    onClick: () -> Unit,
) {
    val contentColor by animateColorAsState(
        targetValue = if (selected) NeonCyan else TextSecondary,
        label = "nav_color",
    )
    val bgColor by animateColorAsState(
        targetValue = if (selected) NeonCyan.copy(alpha = 0.09f) else Color.Transparent,
        label = "nav_bg",
    )

    Column(
        modifier = Modifier
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .testTag(testTag),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = contentColor,
            modifier = Modifier.size(20.dp),
        )
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            color = contentColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
fun NeonGradientButton(
    text: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "neon_gradient_btn",
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .shadow(
                elevation = 16.dp,
                shape = RoundedCornerShape(16.dp),
                ambientColor = NeonCyan.copy(alpha = 0.35f),
                spotColor = NeonCyan.copy(alpha = 0.35f),
            )
            .clip(RoundedCornerShape(16.dp))
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(NeonCyan, NeonPurple),
                ),
            )
            .clickable(onClick = onClick)
            .padding(vertical = 16.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color.Black,
                modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = text,
                color = Color.Black,
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
            )
        }
    }
}

@Composable
fun NeonToggleSwitch(
    checked: Boolean,
    onToggle: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier,
) {
    val trackColor by animateColorAsState(
        targetValue = if (checked) NeonCyan else Color(0x1AFFFFFF),
        label = "toggle_track",
    )
    // Visual switch is 42.dp wide x 24.dp tall inside a 48.dp accessible target
    val knobOffset by animateDpAsState(
        targetValue = if (checked) 21.dp else 3.dp,
        label = "toggle_knob",
    )

    Box(
        modifier = modifier
            .minimumInteractiveComponentSize()
            .size(48.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onToggle)
            .testTag(testTag),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .width(42.dp)
                .height(24.dp)
                .then(
                    if (checked) {
                        Modifier.shadow(
                            elevation = 10.dp,
                            shape = RoundedCornerShape(20.dp),
                            ambientColor = NeonCyan,
                            spotColor = NeonCyan,
                        )
                    } else {
                        Modifier
                    },
                )
                .clip(RoundedCornerShape(20.dp))
                .background(trackColor),
        ) {
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .offset(x = knobOffset)
                    .size(18.dp)
                    .clip(CircleShape)
                    .background(Color.White),
            )
        }
    }
}
