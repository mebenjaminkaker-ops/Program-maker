package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BgDark = Color(0xFF05050A)
val BgTopPurple = Color(0xFF1A0B2E)
val SuccessBgTop = Color(0xFF0B1A20)

val NeonCyan = Color(0xFF00F3FF)
val NeonMagenta = Color(0xFFFF00EA)
val NeonPurple = Color(0xFFB400FF)
val NeonRed = Color(0xFFFF3860)

val GlassBg = Color(0xB30F0F19)
val GlassCardBg = Color(0x08FFFFFF)
val GlassBorder = Color(0x14FFFFFF)
val NavBarBg = Color(0xD90A0A0F)
val TrackBg = Color(0x1AFFFFFF)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0x80FFFFFF)
