package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.ShizukuAppInfo
import com.example.data.model.ShizukuStatus
import com.example.ui.components.NeonToggleSwitch
import com.example.ui.theme.GlassCardBg
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SettingsScreen(
    hasFileAccess: Boolean,
    hasUsageStatsAccess: Boolean,
    shizukuStatus: ShizukuStatus,
    shizukuRamEnabled: Boolean,
    shizukuApps: List<ShizukuAppInfo>,
    shizukuMessage: String?,
    onToggleFileAccess: () -> Unit,
    onToggleShizuku: () -> Unit,
    onOpenShizukuApp: () -> Unit,
    onForceStopPackage: (String) -> Unit,
    onForceStopAll: () -> Unit,
    onToggleUsageStats: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
    ) {
        Text(
            text = stringResource(R.string.settings_permissions_title),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
        Spacer(modifier = Modifier.height(12.dp))

        // 1. File access toggle card
        SettingsToggleCard(
            title = stringResource(R.string.settings_file_access_title),
            subtitle = if (hasFileAccess) {
                stringResource(R.string.settings_file_access_granted)
            } else {
                stringResource(R.string.settings_file_access_desc)
            },
            checked = hasFileAccess,
            testTag = "settings_file_access_toggle",
            onToggle = onToggleFileAccess,
        )

        Spacer(modifier = Modifier.height(12.dp))

        // 2. Shizuku RAM access toggle card
        val shizukuSubtitle = when (shizukuStatus) {
            ShizukuStatus.NOT_INSTALLED -> stringResource(R.string.settings_shizuku_not_installed)
            ShizukuStatus.SERVICE_NOT_RUNNING -> stringResource(R.string.settings_shizuku_not_installed)
            ShizukuStatus.PERMISSION_REQUIRED -> stringResource(R.string.settings_shizuku_running)
            ShizukuStatus.GRANTED -> stringResource(R.string.settings_shizuku_granted)
        }
        SettingsToggleCard(
            title = stringResource(R.string.settings_shizuku_title),
            subtitle = "${stringResource(R.string.settings_shizuku_desc)} • $shizukuSubtitle",
            checked = shizukuRamEnabled && shizukuStatus == ShizukuStatus.GRANTED,
            testTag = "settings_shizuku_toggle",
            onToggle = onToggleShizuku,
        )

        if (!shizukuMessage.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(NeonCyan.copy(alpha = 0.08f))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
            ) {
                Text(
                    text = shizukuMessage,
                    fontSize = 11.sp,
                    color = NeonCyan,
                )
            }
        }

        if (shizukuStatus == ShizukuStatus.SERVICE_NOT_RUNNING) {
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedButton(
                onClick = onOpenShizukuApp,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("settings_open_shizuku_btn"),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, NeonPurple.copy(alpha = 0.5f)),
            ) {
                Text(
                    text = stringResource(R.string.settings_shizuku_open_app),
                    color = NeonPurple,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
        }

        // Interactive background user packages list when Shizuku is granted and enabled
        if (shizukuStatus == ShizukuStatus.GRANTED && shizukuRamEnabled) {
            Spacer(modifier = Modifier.height(12.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = GlassCardBg,
                border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.25f)),
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Outlined.Memory,
                                contentDescription = null,
                                tint = NeonCyan,
                                modifier = Modifier.size(16.dp),
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stringResource(R.string.settings_shizuku_apps_title),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                            )
                        }
                    }

                    if (shizukuApps.isEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = stringResource(R.string.settings_shizuku_no_apps),
                            fontSize = 11.sp,
                            color = TextSecondary,
                        )
                    } else {
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = onForceStopAll,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NeonCyan,
                                contentColor = Color.Black,
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("shizuku_force_stop_all_btn"),
                        ) {
                            Text(
                                text = stringResource(R.string.settings_shizuku_force_stop_all),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        shizukuApps.take(15).forEachIndexed { idx, app ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .minimumInteractiveComponentSize()
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(end = 8.dp),
                                ) {
                                    Text(
                                        text = app.appName,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    Text(
                                        text = app.packageName,
                                        fontSize = 10.sp,
                                        color = TextSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }

                                OutlinedButton(
                                    onClick = { onForceStopPackage(app.packageName) },
                                    enabled = !app.isStopping,
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.5f)),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("shizuku_stop_${app.packageName}"),
                                ) {
                                    if (app.isStopping) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(14.dp),
                                            color = NeonCyan,
                                            strokeWidth = 2.dp,
                                        )
                                    } else {
                                        Text(
                                            text = stringResource(R.string.settings_shizuku_force_stop),
                                            fontSize = 11.sp,
                                            color = NeonCyan,
                                            fontWeight = FontWeight.Bold,
                                        )
                                    }
                                }
                            }
                            if (idx < shizukuApps.take(15).lastIndex) {
                                HorizontalDivider(color = Color.White.copy(alpha = 0.05f))
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 3. Usage Access toggle for StorageStatsManager app size breakdown
        SettingsToggleCard(
            title = stringResource(R.string.settings_usage_stats_title),
            subtitle = stringResource(R.string.settings_usage_stats_desc),
            checked = hasUsageStatsAccess,
            testTag = "settings_usage_stats_toggle",
            onToggle = onToggleUsageStats,
        )

        Spacer(modifier = Modifier.height(20.dp))

        // 4. App Version Info Card
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = GlassCardBg,
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.06f)),
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = stringResource(R.string.app_name),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = stringResource(R.string.settings_version_subtitle),
                    fontSize = 10.sp,
                    color = TextSecondary,
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun SettingsToggleCard(
    title: String,
    subtitle: String,
    checked: Boolean,
    testTag: String,
    onToggle: () -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = GlassCardBg,
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.06f)),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 10.dp),
            ) {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = subtitle,
                    fontSize = 10.sp,
                    color = TextSecondary,
                )
            }
            NeonToggleSwitch(
                checked = checked,
                onToggle = onToggle,
                testTag = testTag,
            )
        }
    }
}
