package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.CleanupLogEntity
import com.example.data.local.CleanupRepository
import com.example.data.model.CleanupResultSummary
import com.example.data.model.DuplicatePhotoItem
import com.example.data.model.LargeFileItem
import com.example.data.model.MainTab
import com.example.data.model.ScanProgressState
import com.example.data.model.ShizukuAppInfo
import com.example.data.model.ShizukuStatus
import com.example.data.model.StorageSummary
import com.example.data.model.TempFileItem
import com.example.data.system.FileScanner
import com.example.data.system.ShizukuManager
import com.example.data.system.StorageAnalyzer
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val storageAnalyzer = StorageAnalyzer(application)
    private val fileScanner = FileScanner(application, storageAnalyzer)
    private val shizukuManager = ShizukuManager(application)
    private val repository = CleanupRepository(AppDatabase.getInstance(application).cleanupLogDao())

    private val _activeTab = MutableStateFlow(MainTab.DASHBOARD)
    val activeTab: StateFlow<MainTab> = _activeTab.asStateFlow()

    private val _storageSummary = MutableStateFlow(StorageSummary())
    val storageSummary: StateFlow<StorageSummary> = _storageSummary.asStateFlow()

    private val _scanProgress = MutableStateFlow(ScanProgressState())
    val scanProgress: StateFlow<ScanProgressState> = _scanProgress.asStateFlow()

    private val _tempFiles = MutableStateFlow<List<TempFileItem>>(emptyList())
    val tempFiles: StateFlow<List<TempFileItem>> = _tempFiles.asStateFlow()

    private val _duplicatePhotos = MutableStateFlow<List<DuplicatePhotoItem>>(emptyList())
    val duplicatePhotos: StateFlow<List<DuplicatePhotoItem>> = _duplicatePhotos.asStateFlow()

    private val _largeFiles = MutableStateFlow<List<LargeFileItem>>(emptyList())
    val largeFiles: StateFlow<List<LargeFileItem>> = _largeFiles.asStateFlow()

    private val _hasAllFilesAccess = MutableStateFlow(false)
    val hasAllFilesAccess: StateFlow<Boolean> = _hasAllFilesAccess.asStateFlow()

    private val _hasMediaAccess = MutableStateFlow(false)
    val hasMediaAccess: StateFlow<Boolean> = _hasMediaAccess.asStateFlow()

    private val _shizukuStatus = MutableStateFlow(ShizukuStatus.NOT_INSTALLED)
    val shizukuStatus: StateFlow<ShizukuStatus> = _shizukuStatus.asStateFlow()

    private val _shizukuRamEnabled = MutableStateFlow(false)
    val shizukuRamEnabled: StateFlow<Boolean> = _shizukuRamEnabled.asStateFlow()

    private val _shizukuApps = MutableStateFlow<List<ShizukuAppInfo>>(emptyList())
    val shizukuApps: StateFlow<List<ShizukuAppInfo>> = _shizukuApps.asStateFlow()

    private val _shizukuMessage = MutableStateFlow<String?>(null)
    val shizukuMessage: StateFlow<String?> = _shizukuMessage.asStateFlow()

    private val _showSafeConfirmDialog = MutableStateFlow(false)
    val showSafeConfirmDialog: StateFlow<Boolean> = _showSafeConfirmDialog.asStateFlow()

    private val _showSensitiveConfirmDialog = MutableStateFlow(false)
    val showSensitiveConfirmDialog: StateFlow<Boolean> = _showSensitiveConfirmDialog.asStateFlow()

    private val _cleanupSuccessSummary = MutableStateFlow<CleanupResultSummary?>(null)
    val cleanupSuccessSummary: StateFlow<CleanupResultSummary?> = _cleanupSuccessSummary.asStateFlow()

    private val _pendingMediaDeleteUris = MutableStateFlow<List<Uri>?>(null)
    val pendingMediaDeleteUris: StateFlow<List<Uri>?> = _pendingMediaDeleteUris.asStateFlow()

    // Pending metadata when waiting for system MediaStore.createDeleteRequest dialog
    private var pendingDirectFreedBytes: Long = 0L
    private var pendingDirectDeletedCount: Int = 0
    private var pendingMediaBytes: Long = 0L
    private var pendingMediaCount: Int = 0
    private var pendingCleanupDescription: String = ""
    private var pendingCleanupWasSensitive: Boolean = false

    val historyLogs: StateFlow<List<CleanupLogEntity>> = repository.allLogs
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList(),
        )

    val totalFreedHistoryBytes: StateFlow<Long> = repository.totalFreedBytes
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0L,
        )

    init {
        shizukuManager.registerListeners {
            viewModelScope.launch {
                refreshShizukuState()
            }
        }
        refreshEnvironmentAndStorage()
    }

    override fun onCleared() {
        super.onCleared()
        shizukuManager.unregisterListeners()
    }

    fun selectTab(tab: MainTab) {
        _activeTab.value = tab
        if (tab == MainTab.SPACE || tab == MainTab.DASHBOARD) {
            refreshEnvironmentAndStorage()
        }
    }

    fun refreshEnvironmentAndStorage() {
        _hasAllFilesAccess.value = storageAnalyzer.hasAllFilesPermission()
        _hasMediaAccess.value = storageAnalyzer.hasMediaPermissions()
        refreshShizukuState()

        viewModelScope.launch {
            val summary = storageAnalyzer.analyzeStorage()
            _storageSummary.value = summary
            if ((_hasAllFilesAccess.value || _hasMediaAccess.value) && !_scanProgress.value.isScanning) {
                if (!_scanProgress.value.hasScanned) {
                    val quickLarge = fileScanner.scanLargeFiles { }
                    _largeFiles.value = quickLarge
                }
            }
        }
    }

    fun refreshShizukuState() {
        val status = shizukuManager.getStatus()
        _shizukuStatus.value = status
        if (status == ShizukuStatus.GRANTED) {
            _shizukuRamEnabled.value = true
            viewModelScope.launch {
                _shizukuApps.value = shizukuManager.getBackgroundUserPackages()
            }
        } else {
            _shizukuRamEnabled.value = false
            _shizukuApps.value = emptyList()
        }
    }

    fun toggleShizukuRamAccess() {
        val currentStatus = shizukuManager.getStatus()
        _shizukuStatus.value = currentStatus
        when (currentStatus) {
            ShizukuStatus.GRANTED -> {
                _shizukuRamEnabled.value = !_shizukuRamEnabled.value
                _shizukuMessage.value = if (_shizukuRamEnabled.value) {
                    "دسترسی رم Shizuku فعال است."
                } else {
                    "حالت مدیریت رم موقتاً غیرفعال شد."
                }
            }
            ShizukuStatus.PERMISSION_REQUIRED -> {
                val requested = shizukuManager.requestPermission()
                _shizukuMessage.value = if (requested) {
                    "درخواست مجوز به Shizuku ارسال شد."
                } else {
                    "خطا در ارسال درخواست مجوز Shizuku."
                }
            }
            ShizukuStatus.SERVICE_NOT_RUNNING -> {
                _shizukuMessage.value = "سرویس Shizuku در حال اجرا نیست. ابتدا از برنامه Shizuku سرویس را فعال کنید."
            }
            ShizukuStatus.NOT_INSTALLED -> {
                _shizukuMessage.value = "برنامه Shizuku روی دستگاه نصب نیست."
            }
        }
    }

    fun openShizukuApp(): Boolean {
        return shizukuManager.launchShizukuApp()
    }

    fun clearShizukuMessage() {
        _shizukuMessage.value = null
    }

    fun forceStopPackage(packageName: String) {
        viewModelScope.launch {
            _shizukuApps.update { list ->
                list.map { if (it.packageName == packageName) it.copy(isStopping = true) else it }
            }
            val success = shizukuManager.forceStopPackage(packageName)
            val appName = _shizukuApps.value.firstOrNull { it.packageName == packageName }?.appName ?: packageName
            _shizukuApps.update { list ->
                list.map { if (it.packageName == packageName) it.copy(isStopping = false) else it }
            }
            _shizukuMessage.value = if (success) {
                "برنامه «$appName» با موفقیت متوقف شد."
            } else {
                "توقف برنامه «$appName» ناموفق بود."
            }
        }
    }

    fun forceStopAllBackgroundPackages() {
        val targets = _shizukuApps.value
        if (targets.isEmpty()) return
        viewModelScope.launch {
            var stopped = 0
            for (app in targets) {
                _shizukuApps.update { list ->
                    list.map { if (it.packageName == app.packageName) it.copy(isStopping = true) else it }
                }
                if (shizukuManager.forceStopPackage(app.packageName)) {
                    stopped++
                }
                _shizukuApps.update { list ->
                    list.map { if (it.packageName == app.packageName) it.copy(isStopping = false) else it }
                }
            }
            _shizukuMessage.value = "${com.example.util.PersianUtils.toPersianDigits(stopped)} برنامه پس‌زمینه متوقف شدند."
        }
    }

    fun startSmartScan() {
        _activeTab.value = MainTab.CLEANER
        if (_scanProgress.value.isScanning) return

        viewModelScope.launch {
            _scanProgress.value = ScanProgressState(isScanning = true, step1Active = true)

            // Step 1: Temp files
            val temps = fileScanner.scanTempFiles { p ->
                _scanProgress.update { it.copy(step1TempProgress = p) }
            }
            delay(280)
            _scanProgress.update {
                it.copy(
                    step1TempProgress = 1f,
                    step1Active = false,
                    step1Done = true,
                    step2Active = true,
                )
            }

            // Step 2: Large files
            val larges = fileScanner.scanLargeFiles { p ->
                _scanProgress.update { it.copy(step2LargeProgress = p) }
            }
            delay(280)
            _scanProgress.update {
                it.copy(
                    step2LargeProgress = 1f,
                    step2Active = false,
                    step2Done = true,
                    step3Active = true,
                )
            }

            // Step 3: Duplicate photos
            val dups = fileScanner.scanDuplicatePhotos { p ->
                _scanProgress.update { it.copy(step3DupProgress = p) }
            }
            delay(280)

            _tempFiles.value = temps
            _largeFiles.value = larges
            _duplicatePhotos.value = dups
            _scanProgress.value = ScanProgressState(
                isScanning = false,
                step1TempProgress = 1f,
                step1Done = true,
                step2LargeProgress = 1f,
                step2Done = true,
                step3DupProgress = 1f,
                step3Done = true,
                hasScanned = true,
            )
            refreshEnvironmentAndStorage()
        }
    }

    fun toggleTempItem(id: String) {
        _tempFiles.update { list ->
            list.map { if (it.id == id) it.copy(isSelected = !it.isSelected) else it }
        }
    }

    fun toggleDuplicateItem(id: String) {
        _duplicatePhotos.update { list ->
            list.map { if (it.id == id) it.copy(isSelected = !it.isSelected) else it }
        }
    }

    fun toggleLargeItem(id: String) {
        _largeFiles.update { list ->
            list.map { if (it.id == id) it.copy(isSelected = !it.isSelected) else it }
        }
    }

    fun selectLargeFileForCleanup(id: String) {
        _largeFiles.update { list ->
            list.map { if (it.id == id) it.copy(isSelected = true) else it }
        }
        _showSensitiveConfirmDialog.value = true
    }

    fun requestCleanConfirmation() {
        val hasSelectedDups = _duplicatePhotos.value.any { it.isSelected }
        val hasSelectedLarge = _largeFiles.value.any { it.isSelected }
        val hasSelectedTemp = _tempFiles.value.any { it.isSelected }

        if (!hasSelectedDups && !hasSelectedLarge && !hasSelectedTemp) return

        if (hasSelectedDups || hasSelectedLarge) {
            _showSensitiveConfirmDialog.value = true
        } else {
            _showSafeConfirmDialog.value = true
        }
    }

    fun dismissConfirmDialogs() {
        _showSafeConfirmDialog.value = false
        _showSensitiveConfirmDialog.value = false
    }

    fun executeClean(isSensitive: Boolean) {
        _showSafeConfirmDialog.value = false
        _showSensitiveConfirmDialog.value = false

        val selectedTemp = _tempFiles.value.filter { it.isSelected }
        val selectedDups = _duplicatePhotos.value.filter { it.isSelected }
        val selectedLarge = _largeFiles.value.filter { it.isSelected }

        if (selectedTemp.isEmpty() && selectedDups.isEmpty() && selectedLarge.isEmpty()) return

        val parts = mutableListOf<String>()
        if (selectedTemp.isNotEmpty()) parts.add("فایل‌های موقت")
        if (selectedDups.isNotEmpty()) parts.add("عکس‌های تکراری")
        if (selectedLarge.isNotEmpty()) parts.add("فایل‌های حجیم")
        val description = "پاکسازی ${parts.joinToString(" و ")}"

        viewModelScope.launch {
            val result = fileScanner.deleteSelectedItems(
                tempItems = selectedTemp,
                duplicateItems = selectedDups,
                largeItems = selectedLarge,
            )

            // Remove items that were directly deleted
            if (result.pendingMediaStoreUris.isEmpty()) {
                finalizeCleanup(
                    freedBytes = result.freedBytes,
                    deletedCount = result.deletedCount,
                    description = description,
                    isSensitive = isSensitive,
                )
            } else {
                // Store direct results & wait for MediaStore.createDeleteRequest consent
                pendingDirectFreedBytes = result.freedBytes
                pendingDirectDeletedCount = result.deletedCount
                val pendingUriStrings = result.pendingMediaStoreUris.map { it.toString() }.toSet()
                pendingMediaBytes = selectedDups.filter { it.uriString in pendingUriStrings }.sumOf { it.sizeBytes } +
                    selectedLarge.filter { it.uriString in pendingUriStrings }.sumOf { it.sizeBytes }
                pendingMediaCount = result.pendingMediaStoreUris.size
                pendingCleanupDescription = description
                pendingCleanupWasSensitive = isSensitive
                _pendingMediaDeleteUris.value = result.pendingMediaStoreUris
            }
        }
    }

    fun onMediaStoreDeleteResult(granted: Boolean) {
        _pendingMediaDeleteUris.value = null
        viewModelScope.launch {
            val totalFreed = pendingDirectFreedBytes + if (granted) pendingMediaBytes else 0L
            val totalCount = pendingDirectDeletedCount + if (granted) pendingMediaCount else 0
            finalizeCleanup(
                freedBytes = totalFreed,
                deletedCount = totalCount,
                description = pendingCleanupDescription,
                isSensitive = pendingCleanupWasSensitive,
            )
            pendingDirectFreedBytes = 0L
            pendingDirectDeletedCount = 0
            pendingMediaBytes = 0L
            pendingMediaCount = 0
        }
    }

    private suspend fun finalizeCleanup(
        freedBytes: Long,
        deletedCount: Int,
        description: String,
        isSensitive: Boolean,
    ) {
        if (deletedCount > 0 || freedBytes > 0L) {
            repository.recordCleanup(
                description = description,
                freedBytes = freedBytes,
                filesDeletedCount = deletedCount,
                isSensitiveCleanup = isSensitive,
            )
        }

        _tempFiles.update { list -> list.filterNot { it.isSelected } }
        _duplicatePhotos.update { list -> list.filterNot { it.isSelected } }
        _largeFiles.update { list -> list.filterNot { it.isSelected } }

        _cleanupSuccessSummary.value = CleanupResultSummary(
            freedBytes = freedBytes,
            deletedFilesCount = deletedCount,
        )
        refreshEnvironmentAndStorage()
    }

    fun closeSuccessOverlay() {
        _cleanupSuccessSummary.value = null
        _activeTab.value = MainTab.DASHBOARD
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }
}
