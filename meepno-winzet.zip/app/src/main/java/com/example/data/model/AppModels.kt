package com.example.data.model

enum class MainTab {
    DASHBOARD,
    CLEANER,
    SPACE,
    HISTORY,
    SETTINGS,
}

data class StorageSummary(
    val totalBytes: Long = 0L,
    val usedBytes: Long = 0L,
    val freeBytes: Long = 0L,
    val usedPercent: Int = 0,
    val videosBytes: Long = 0L,
    val imagesBytes: Long = 0L,
    val appsBytes: Long = 0L,
    val hasUsageStatsPermission: Boolean = false,
)

data class TempFileItem(
    val id: String,
    val name: String,
    val paths: List<String>,
    val sizeBytes: Long,
    val isSelected: Boolean = true,
    val isAppCache: Boolean = false,
)

data class DuplicatePhotoItem(
    val id: String,
    val name: String,
    val path: String,
    val uriString: String,
    val sizeBytes: Long,
    val sha256: String,
    val groupIndex: Int,
    val isOriginal: Boolean,
    val isSelected: Boolean,
)

data class LargeFileItem(
    val id: String,
    val name: String,
    val path: String,
    val uriString: String,
    val sizeBytes: Long,
    val mimeType: String,
    val isSelected: Boolean = false,
)

data class ScanProgressState(
    val isScanning: Boolean = false,
    val step1TempProgress: Float = 0f,
    val step1Active: Boolean = false,
    val step1Done: Boolean = false,
    val step2LargeProgress: Float = 0f,
    val step2Active: Boolean = false,
    val step2Done: Boolean = false,
    val step3DupProgress: Float = 0f,
    val step3Active: Boolean = false,
    val step3Done: Boolean = false,
    val hasScanned: Boolean = false,
)

data class ShizukuAppInfo(
    val packageName: String,
    val appName: String,
    val isStopping: Boolean = false,
)

enum class ShizukuStatus {
    NOT_INSTALLED,
    SERVICE_NOT_RUNNING,
    PERMISSION_REQUIRED,
    GRANTED,
}

data class CleanupResultSummary(
    val freedBytes: Long,
    val deletedFilesCount: Int,
)
