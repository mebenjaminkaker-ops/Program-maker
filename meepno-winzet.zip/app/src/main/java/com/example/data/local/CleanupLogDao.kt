package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CleanupLogDao {
    @Query("SELECT * FROM cleanup_logs ORDER BY timestampMillis DESC")
    fun getAllLogs(): Flow<List<CleanupLogEntity>>

    @Query("SELECT SUM(freedBytes) FROM cleanup_logs")
    fun getTotalFreedBytes(): Flow<Long?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: CleanupLogEntity)

    @Query("DELETE FROM cleanup_logs")
    suspend fun clearAll()
}
