package com.example.data.local

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class CleanupRepository(private val dao: CleanupLogDao) {
    val allLogs: Flow<List<CleanupLogEntity>> = dao.getAllLogs()
    val totalFreedBytes: Flow<Long> = dao.getTotalFreedBytes().map { it ?: 0L }

    suspend fun recordCleanup(
        description: String,
        freedBytes: Long,
        filesDeletedCount: Int,
        isSensitiveCleanup: Boolean,
    ) {
        dao.insertLog(
            CleanupLogEntity(
                timestampMillis = System.currentTimeMillis(),
                description = description,
                freedBytes = freedBytes,
                filesDeletedCount = filesDeletedCount,
                accentType = if (isSensitiveCleanup) 1 else 0,
            ),
        )
    }

    suspend fun clearHistory() {
        dao.clearAll()
    }
}
