package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cleanup_logs")
data class CleanupLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val timestampMillis: Long = System.currentTimeMillis(),
    val description: String,
    val freedBytes: Long,
    val filesDeletedCount: Int,
    val accentType: Int = 0, // 0 = cyan, 1 = purple
)
