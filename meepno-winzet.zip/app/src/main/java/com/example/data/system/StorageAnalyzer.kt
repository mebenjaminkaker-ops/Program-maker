package com.example.data.system

import android.Manifest
import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Process
import android.os.StatFs
import android.os.storage.StorageManager
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import com.example.data.model.StorageSummary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

class StorageAnalyzer(private val context: Context) {

    fun hasAllFilesPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun hasMediaPermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_MEDIA_IMAGES,
            ) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_MEDIA_VIDEO,
                ) == PackageManager.PERMISSION_GRANTED ||
                hasAllFilesPermission()
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_EXTERNAL_STORAGE,
            ) == PackageManager.PERMISSION_GRANTED ||
                hasAllFilesPermission()
        } else {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_EXTERNAL_STORAGE,
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun hasUsageStatsPermission(): Boolean {
        return try {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager
                ?: return false
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    context.packageName,
                )
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    context.packageName,
                )
            }
            mode == AppOpsManager.MODE_ALLOWED
        } catch (_: Exception) {
            false
        }
    }

    suspend fun analyzeStorage(): StorageSummary = withContext(Dispatchers.IO) {
        val (totalBytes, freeBytes) = readDeviceCapacity()
        val usedBytes = (totalBytes - freeBytes).coerceAtLeast(0L)
        val usedPercent = if (totalBytes > 0L) {
            ((usedBytes.toDouble() / totalBytes.toDouble()) * 100.0).toInt().coerceIn(0, 100)
        } else {
            0
        }

        val canReadMedia = hasMediaPermissions()
        val videosBytes = if (canReadMedia) {
            queryMediaTotalBytes(MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
        } else {
            0L
        }
        val imagesBytes = if (canReadMedia) {
            queryMediaTotalBytes(MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        } else {
            0L
        }

        val usageStatsGranted = hasUsageStatsPermission()
        val appsBytes = calculateAppsBytes(usageStatsGranted)

        StorageSummary(
            totalBytes = totalBytes,
            usedBytes = usedBytes,
            freeBytes = freeBytes,
            usedPercent = usedPercent,
            videosBytes = videosBytes,
            imagesBytes = imagesBytes,
            appsBytes = appsBytes,
            hasUsageStatsPermission = usageStatsGranted,
        )
    }

    private fun readDeviceCapacity(): Pair<Long, Long> {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val statsManager =
                    context.getSystemService(Context.STORAGE_STATS_SERVICE) as? StorageStatsManager
                if (statsManager != null) {
                    val total = statsManager.getTotalBytes(StorageManager.UUID_DEFAULT)
                    val free = statsManager.getFreeBytes(StorageManager.UUID_DEFAULT)
                    if (total > 0L) {
                        return total to free.coerceAtMost(total)
                    }
                }
            } catch (_: Exception) {
                // Fall back to StatFs below
            }
        }
        return try {
            val statFs = StatFs(Environment.getDataDirectory().path)
            val total = statFs.totalBytes
            val free = statFs.availableBytes
            total to free.coerceAtMost(total)
        } catch (_: Exception) {
            0L to 0L
        }
    }

    private fun queryMediaTotalBytes(uri: Uri): Long {
        var total = 0L
        val projection = arrayOf(MediaStore.MediaColumns.SIZE)
        try {
            context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
                val sizeCol = cursor.getColumnIndex(MediaStore.MediaColumns.SIZE)
                if (sizeCol >= 0) {
                    while (cursor.moveToNext()) {
                        val size = cursor.getLong(sizeCol)
                        if (size > 0L) total += size
                    }
                }
            }
        } catch (_: Exception) {
            // Permission revoked or MediaStore unavailable
        }
        return total
    }

    private fun calculateAppsBytes(hasUsageAccess: Boolean): Long {
        val pm = context.packageManager
        var total = 0L

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && hasUsageAccess) {
            val statsManager =
                context.getSystemService(Context.STORAGE_STATS_SERVICE) as? StorageStatsManager
            if (statsManager != null) {
                val userHandle = Process.myUserHandle()
                val installed = try {
                    pm.getInstalledApplications(0)
                } catch (_: Exception) {
                    emptyList()
                }
                for (app in installed) {
                    try {
                        val stats = statsManager.queryStatsForPackage(
                            StorageManager.UUID_DEFAULT,
                            app.packageName,
                            userHandle,
                        )
                        total += (stats.appBytes + stats.dataBytes + stats.cacheBytes).coerceAtLeast(0L)
                    } catch (_: Exception) {
                        // Skip inaccessible packages
                    }
                }
                if (total > 0L) return total
            }
        }

        // Fallback without Usage Access: own app via StorageStatsManager + installed APK file lengths
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val statsManager =
                    context.getSystemService(Context.STORAGE_STATS_SERVICE) as? StorageStatsManager
                if (statsManager != null) {
                    val ownStats = statsManager.queryStatsForPackage(
                        StorageManager.UUID_DEFAULT,
                        context.packageName,
                        Process.myUserHandle(),
                    )
                    total += ownStats.appBytes + ownStats.dataBytes + ownStats.cacheBytes
                }
            } catch (_: Exception) {
            }
        }

        val installed = try {
            pm.getInstalledApplications(0)
        } catch (_: Exception) {
            emptyList()
        }
        for (app in installed) {
            if (app.packageName == context.packageName) continue
            val src = app.sourceDir ?: continue
            try {
                val apkFile = File(src)
                if (apkFile.exists() && apkFile.canRead()) {
                    total += apkFile.length()
                }
            } catch (_: Exception) {
            }
        }
        return total
    }
}
