package com.example.data.system

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.example.data.model.DuplicatePhotoItem
import com.example.data.model.LargeFileItem
import com.example.data.model.TempFileItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.util.Locale

data class FullScanResult(
    val tempFiles: List<TempFileItem>,
    val largeFiles: List<LargeFileItem>,
    val duplicatePhotos: List<DuplicatePhotoItem>,
)

data class DeletionExecutionResult(
    val freedBytes: Long,
    val deletedCount: Int,
    val pendingMediaStoreUris: List<Uri>,
)

class FileScanner(
    private val context: Context,
    private val storageAnalyzer: StorageAnalyzer,
) {

    companion object {
        const val LARGE_FILE_THRESHOLD_BYTES: Long = 100L * 1024L * 1024L // 100 MB
        private val TEMP_EXTENSIONS = setOf("tmp", "temp", "log", "bak", "exo", "dmp")
        private val TEMP_DIR_NAMES = setOf("temp", "tmp", ".trash", "cache", ".thumbnails")
    }

    suspend fun scanTempFiles(onProgress: (Float) -> Unit): List<TempFileItem> = withContext(Dispatchers.IO) {
        onProgress(0.15f)
        val items = mutableListOf<TempFileItem>()

        // 1. App's own internal & external cache directories
        val appCachePaths = mutableListOf<String>()
        var appCacheSize = 0L
        listOfNotNull(context.cacheDir, context.externalCacheDir).forEach { dir ->
            val (size, files) = collectDirFiles(dir)
            if (size > 0L) {
                appCacheSize += size
                appCachePaths.addAll(files)
            }
        }
        if (appCacheSize > 0L) {
            items.add(
                TempFileItem(
                    id = "app_cache",
                    name = "کش و فایل‌های موقت برنامه",
                    paths = appCachePaths,
                    sizeBytes = appCacheSize,
                    isSelected = true,
                    isAppCache = true,
                ),
            )
        }
        onProgress(0.45f)

        // 2. External storage temp/log/bak/thumbdata/cache files when accessible
        if (storageAnalyzer.hasAllFilesPermission() || storageAnalyzer.hasMediaPermissions()) {
            val root = Environment.getExternalStorageDirectory()
            if (root != null && root.exists() && root.canRead()) {
                val tempExtensionPaths = mutableListOf<String>()
                var tempExtensionSize = 0L
                val thumbPaths = mutableListOf<String>()
                var thumbSize = 0L

                walkSafe(root, maxDepth = 6) { file ->
                    val nameLower = file.name.lowercase(Locale.US)
                    val ext = file.extension.lowercase(Locale.US)
                    val parentName = file.parentFile?.name?.lowercase(Locale.US).orEmpty()

                    when {
                        nameLower.startsWith(".thumbdata") || nameLower.startsWith("thumbdata") -> {
                            val len = file.length()
                            if (len > 0L) {
                                thumbPaths.add(file.absolutePath)
                                thumbSize += len
                            }
                        }
                        ext in TEMP_EXTENSIONS || parentName in TEMP_DIR_NAMES -> {
                            val len = file.length()
                            if (len > 0L) {
                                tempExtensionPaths.add(file.absolutePath)
                                tempExtensionSize += len
                            }
                        }
                    }
                }

                if (tempExtensionSize > 0L && tempExtensionPaths.isNotEmpty()) {
                    items.add(
                        TempFileItem(
                            id = "ext_temp_files",
                            name = "فایل‌های موقت و لاگ سیستم (${tempExtensionPaths.size})",
                            paths = tempExtensionPaths,
                            sizeBytes = tempExtensionSize,
                            isSelected = true,
                        ),
                    )
                }

                if (thumbSize > 0L && thumbPaths.isNotEmpty()) {
                    items.add(
                        TempFileItem(
                            id = "thumbdata_cache",
                            name = "کش تصاویر بندانگشتی (${thumbPaths.size})",
                            paths = thumbPaths,
                            sizeBytes = thumbSize,
                            isSelected = true,
                        ),
                    )
                }
            }
        }
        onProgress(1.0f)
        items
    }

    suspend fun scanLargeFiles(onProgress: (Float) -> Unit): List<LargeFileItem> = withContext(Dispatchers.IO) {
        onProgress(0.2f)
        val foundByPath = LinkedHashMap<String, LargeFileItem>()

        // 1. Query MediaStore.Files for large files >= 100 MB
        if (storageAnalyzer.hasMediaPermissions() || storageAnalyzer.hasAllFilesPermission()) {
            val filesUri = MediaStore.Files.getContentUri("external")
            val projection = arrayOf(
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DISPLAY_NAME,
                MediaStore.Files.FileColumns.DATA,
                MediaStore.Files.FileColumns.SIZE,
                MediaStore.Files.FileColumns.MIME_TYPE,
            )
            val selection = "${MediaStore.Files.FileColumns.SIZE} >= ?"
            val selectionArgs = arrayOf(LARGE_FILE_THRESHOLD_BYTES.toString())
            val sortOrder = "${MediaStore.Files.FileColumns.SIZE} DESC"

            try {
                context.contentResolver.query(filesUri, projection, selection, selectionArgs, sortOrder)?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                    val nameCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME)
                    val dataCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATA)
                    val sizeCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.SIZE)
                    val mimeCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.MIME_TYPE)

                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idCol)
                        val path = if (dataCol >= 0) cursor.getString(dataCol).orEmpty() else ""
                        val size = if (sizeCol >= 0) cursor.getLong(sizeCol) else 0L
                        val rawName = if (nameCol >= 0) cursor.getString(nameCol) else null
                        val name = rawName ?: File(path).name.ifBlank { "file_$id" }
                        val mime = if (mimeCol >= 0) cursor.getString(mimeCol).orEmpty() else ""
                        val itemUri = ContentUris.withAppendedId(filesUri, id).toString()
                        val key = path.ifBlank { itemUri }

                        if (size >= LARGE_FILE_THRESHOLD_BYTES && (path.isBlank() || File(path).exists())) {
                            foundByPath[key] = LargeFileItem(
                                id = "large_$id",
                                name = name,
                                path = path,
                                uriString = itemUri,
                                sizeBytes = size,
                                mimeType = mime,
                                isSelected = false,
                            )
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }
        onProgress(0.65f)

        // 2. Walk external storage directly when All Files Access is granted to catch non-indexed files (APKs, ZIPs, ISOs)
        if (storageAnalyzer.hasAllFilesPermission()) {
            val root = Environment.getExternalStorageDirectory()
            if (root != null && root.exists() && root.canRead()) {
                walkSafe(root, maxDepth = 7) { file ->
                    val len = file.length()
                    if (len >= LARGE_FILE_THRESHOLD_BYTES) {
                        val path = file.absolutePath
                        if (!foundByPath.containsKey(path)) {
                            foundByPath[path] = LargeFileItem(
                                id = "large_file_${path.hashCode()}",
                                name = file.name,
                                path = path,
                                uriString = Uri.fromFile(file).toString(),
                                sizeBytes = len,
                                mimeType = "",
                                isSelected = false,
                            )
                        }
                    }
                }
            }
        }

        onProgress(1.0f)
        foundByPath.values.sortedByDescending { it.sizeBytes }
    }

    suspend fun scanDuplicatePhotos(onProgress: (Float) -> Unit): List<DuplicatePhotoItem> = withContext(Dispatchers.IO) {
        if (!storageAnalyzer.hasMediaPermissions() && !storageAnalyzer.hasAllFilesPermission()) {
            onProgress(1.0f)
            return@withContext emptyList()
        }

        onProgress(0.15f)
        data class CandidateImage(
            val id: Long,
            val name: String,
            val path: String,
            val uri: Uri,
            val sizeBytes: Long,
        )

        val candidates = mutableListOf<CandidateImage>()
        val seenPaths = HashSet<String>()
        val uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.DATA,
            MediaStore.Images.Media.SIZE,
        )
        val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} ASC"

        try {
            context.contentResolver.query(uri, projection, null, null, sortOrder)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME)
                val dataCol = cursor.getColumnIndex(MediaStore.Images.Media.DATA)
                val sizeCol = cursor.getColumnIndex(MediaStore.Images.Media.SIZE)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val path = if (dataCol >= 0) cursor.getString(dataCol).orEmpty() else ""
                    val size = if (sizeCol >= 0) cursor.getLong(sizeCol) else 0L
                    val name = if (nameCol >= 0) {
                        cursor.getString(nameCol) ?: File(path).name.ifBlank { "IMG_$id.jpg" }
                    } else {
                        File(path).name.ifBlank { "IMG_$id.jpg" }
                    }
                    val itemUri = ContentUris.withAppendedId(uri, id)
                    val actualSize = if (size > 0L) size else if (path.isNotBlank()) File(path).length() else 0L
                    if (actualSize > 0L && (path.isBlank() || File(path).exists())) {
                        val key = path.ifBlank { itemUri.toString() }
                        if (seenPaths.add(key)) {
                            candidates.add(CandidateImage(id, name, path, itemUri, actualSize))
                        }
                    }
                }
            }
        } catch (_: Exception) {
        }

        onProgress(0.45f)

        // Group by file size first; only hash files that share the exact same byte size
        val sizeGroups = candidates.groupBy { it.sizeBytes }.filterValues { it.size >= 2 }
        val totalToHash = sizeGroups.values.sumOf { it.size }.coerceAtLeast(1)
        var hashedCount = 0

        val hashGroups = LinkedHashMap<Pair<Long, String>, MutableList<CandidateImage>>()
        for ((sizeBytes, group) in sizeGroups) {
            for (item in group) {
                val digest = computeSha256(item.path, item.uri)
                hashedCount++
                onProgress(0.45f + (0.5f * hashedCount.toFloat() / totalToHash.toFloat()))
                if (digest != null) {
                    val key = sizeBytes to digest
                    hashGroups.getOrPut(key) { mutableListOf() }.add(item)
                }
            }
        }

        val result = mutableListOf<DuplicatePhotoItem>()
        var groupIdx = 0
        for ((key, group) in hashGroups) {
            if (group.size < 2) continue
            group.forEachIndexed { index, candidate ->
                val isOriginal = index == 0
                result.add(
                    DuplicatePhotoItem(
                        id = "dup_${candidate.id}_${groupIdx}_$index",
                        name = candidate.name,
                        path = candidate.path,
                        uriString = candidate.uri.toString(),
                        sizeBytes = key.first,
                        sha256 = key.second,
                        groupIndex = groupIdx,
                        isOriginal = isOriginal,
                        isSelected = !isOriginal, // Keep oldest original unchecked, pre-select duplicates
                    ),
                )
            }
            groupIdx++
        }

        onProgress(1.0f)
        result
    }

    suspend fun deleteSelectedItems(
        tempItems: List<TempFileItem>,
        duplicateItems: List<DuplicatePhotoItem>,
        largeItems: List<LargeFileItem>,
    ): DeletionExecutionResult = withContext(Dispatchers.IO) {
        var freedBytes = 0L
        var deletedCount = 0
        val pendingUris = mutableListOf<Uri>()

        // 1. Delete temp files & app cache
        for (item in tempItems) {
            if (item.isAppCache) {
                listOfNotNull(context.cacheDir, context.externalCacheDir).forEach { dir ->
                    val deletedStats = clearDirectoryContents(dir)
                    freedBytes += deletedStats.first
                    deletedCount += deletedStats.second
                }
            } else {
                for (path in item.paths) {
                    val file = File(path)
                    if (file.exists()) {
                        val len = file.length()
                        if (file.delete()) {
                            freedBytes += len
                            deletedCount++
                        }
                    }
                }
            }
        }

        // 2. Delete duplicate photos
        for (dup in duplicateItems) {
            val file = if (dup.path.isNotBlank()) File(dup.path) else null
            if (file != null && file.exists() && file.delete()) {
                freedBytes += dup.sizeBytes
                deletedCount++
                // Also remove MediaStore index entry if applicable
                try {
                    context.contentResolver.delete(Uri.parse(dup.uriString), null, null)
                } catch (_: Exception) {
                }
            } else {
                val parsedUri = runCatching { Uri.parse(dup.uriString) }.getOrNull()
                if (parsedUri != null && parsedUri.scheme == "content") {
                    val deletedDirectly = try {
                        context.contentResolver.delete(parsedUri, null, null) > 0
                    } catch (_: SecurityException) {
                        false
                    } catch (_: Exception) {
                        false
                    }
                    if (deletedDirectly) {
                        freedBytes += dup.sizeBytes
                        deletedCount++
                    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        pendingUris.add(parsedUri)
                    }
                }
            }
        }

        // 3. Delete large files
        for (large in largeItems) {
            val file = if (large.path.isNotBlank()) File(large.path) else null
            if (file != null && file.exists() && file.delete()) {
                freedBytes += large.sizeBytes
                deletedCount++
                try {
                    val parsedUri = Uri.parse(large.uriString)
                    if (parsedUri.scheme == "content") {
                        context.contentResolver.delete(parsedUri, null, null)
                    }
                } catch (_: Exception) {
                }
            } else {
                val parsedUri = runCatching { Uri.parse(large.uriString) }.getOrNull()
                if (parsedUri != null && parsedUri.scheme == "content") {
                    val deletedDirectly = try {
                        context.contentResolver.delete(parsedUri, null, null) > 0
                    } catch (_: SecurityException) {
                        false
                    } catch (_: Exception) {
                        false
                    }
                    if (deletedDirectly) {
                        freedBytes += large.sizeBytes
                        deletedCount++
                    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        pendingUris.add(parsedUri)
                    }
                }
            }
        }

        DeletionExecutionResult(
            freedBytes = freedBytes,
            deletedCount = deletedCount,
            pendingMediaStoreUris = pendingUris,
        )
    }

    private fun computeSha256(path: String, uri: Uri): String? {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val buffer = ByteArray(64 * 1024)
            val stream = if (path.isNotBlank() && File(path).canRead()) {
                FileInputStream(path)
            } else {
                context.contentResolver.openInputStream(uri)
            } ?: return null

            stream.use { input ->
                var read = input.read(buffer)
                while (read != -1) {
                    digest.update(buffer, 0, read)
                    read = input.read(buffer)
                }
            }
            digest.digest().joinToString("") { "%02x".format(it) }
        } catch (_: Exception) {
            null
        }
    }

    private fun collectDirFiles(dir: File?): Pair<Long, List<String>> {
        if (dir == null || !dir.exists() || !dir.canRead()) return 0L to emptyList()
        var size = 0L
        val paths = mutableListOf<String>()
        val stack = ArrayDeque<File>()
        stack.add(dir)
        while (stack.isNotEmpty()) {
            val current = stack.removeLast()
            val children = current.listFiles() ?: continue
            for (child in children) {
                if (child.isDirectory) {
                    stack.add(child)
                } else {
                    val len = child.length()
                    if (len > 0L) {
                        size += len
                        paths.add(child.absolutePath)
                    }
                }
            }
        }
        return size to paths
    }

    private fun clearDirectoryContents(dir: File): Pair<Long, Int> {
        if (!dir.exists()) return 0L to 0
        var freed = 0L
        var count = 0
        val children = dir.listFiles() ?: return 0L to 0
        for (child in children) {
            if (child.isDirectory) {
                val sub = clearDirectoryContents(child)
                freed += sub.first
                count += sub.second
                child.delete()
            } else {
                val len = child.length()
                if (child.delete()) {
                    freed += len
                    count++
                }
            }
        }
        return freed to count
    }

    private fun walkSafe(
        root: File,
        maxDepth: Int,
        onFile: (File) -> Unit,
    ) {
        val stack = ArrayDeque<Pair<File, Int>>()
        stack.add(root to 0)
        while (stack.isNotEmpty()) {
            val (dir, depth) = stack.removeLast()
            if (depth > maxDepth || !dir.canRead()) continue

            val dirPath = dir.absolutePath
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
                (dirPath.endsWith("/Android/data") || dirPath.endsWith("/Android/obb"))
            ) {
                continue
            }

            val children = dir.listFiles() ?: continue
            for (child in children) {
                if (child.isDirectory) {
                    if (depth + 1 <= maxDepth && !isSymlink(child)) {
                        stack.add(child to depth + 1)
                    }
                } else if (child.isFile) {
                    onFile(child)
                }
            }
        }
    }

    private fun isSymlink(file: File): Boolean {
        return try {
            val canon = file.canonicalFile
            canon != file.absoluteFile
        } catch (_: Exception) {
            true
        }
    }
}
