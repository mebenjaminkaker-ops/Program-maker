package com.example.data.system

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.IBinder
import com.example.BuildConfig
import com.example.IShizukuTaskService
import com.example.data.model.ShizukuAppInfo
import com.example.data.model.ShizukuStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku

class ShizukuManager(private val context: Context) {

    companion object {
        const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
        const val REQUEST_CODE_SHIZUKU = 2001
    }

    private var onStatusChanged: (() -> Unit)? = null
    private val userService = MutableStateFlow<IShizukuTaskService?>(null)

    private val userServiceArgs = Shizuku.UserServiceArgs(
        ComponentName(context.packageName, ShizukuTaskService::class.java.name),
    )
        .daemon(false)
        .processNameSuffix("shizuku_task")
        .tag("MeepnoShizukuTask")
        .debuggable(BuildConfig.DEBUG)
        .version(BuildConfig.VERSION_CODE)

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            if (binder != null && binder.isBinderAlive) {
                userService.value = IShizukuTaskService.Stub.asInterface(binder)
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            userService.value = null
        }
    }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        onStatusChanged?.invoke()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        userService.value = null
        onStatusChanged?.invoke()
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, _ ->
            if (requestCode == REQUEST_CODE_SHIZUKU) {
                onStatusChanged?.invoke()
            }
        }

    fun registerListeners(onUpdate: () -> Unit) {
        onStatusChanged = onUpdate
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(permissionResultListener)
    }

    fun unregisterListeners() {
        onStatusChanged = null
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        runCatching {
            if (Shizuku.pingBinder()) {
                Shizuku.unbindUserService(userServiceArgs, serviceConnection, true)
            }
        }
    }

    fun isShizukuAppInstalled(): Boolean {
        return try {
            context.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun launchShizukuApp(): Boolean {
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE)
                ?: return false
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun getStatus(): ShizukuStatus {
        val installed = isShizukuAppInstalled()
        val binderAlive = try {
            Shizuku.pingBinder()
        } catch (_: Exception) {
            false
        }

        if (!binderAlive) {
            return if (installed) ShizukuStatus.SERVICE_NOT_RUNNING else ShizukuStatus.NOT_INSTALLED
        }

        return try {
            if (Shizuku.isPreV11()) {
                ShizukuStatus.SERVICE_NOT_RUNNING
            } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                ShizukuStatus.GRANTED
            } else {
                ShizukuStatus.PERMISSION_REQUIRED
            }
        } catch (_: Exception) {
            ShizukuStatus.SERVICE_NOT_RUNNING
        }
    }

    fun requestPermission(): Boolean {
        return try {
            if (!Shizuku.pingBinder() || Shizuku.isPreV11()) return false
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) return true
            Shizuku.requestPermission(REQUEST_CODE_SHIZUKU)
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun getBackgroundUserPackages(): List<ShizukuAppInfo> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val launchIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = try {
            pm.queryIntentActivities(launchIntent, 0)
        } catch (_: Exception) {
            emptyList()
        }

        val seen = HashSet<String>()
        val result = mutableListOf<ShizukuAppInfo>()

        for (info in resolveInfos) {
            val appInfo = info.activityInfo?.applicationInfo ?: continue
            val pkg = appInfo.packageName
            if (pkg == context.packageName || pkg == SHIZUKU_PACKAGE) continue
            if (!seen.add(pkg)) continue

            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            if (isSystem) continue

            val label = try {
                pm.getApplicationLabel(appInfo).toString()
            } catch (_: Exception) {
                pkg
            }
            result.add(ShizukuAppInfo(packageName = pkg, appName = label))
        }

        result.sortedBy { it.appName }
    }

    private suspend fun getOrBindUserService(): IShizukuTaskService? {
        val existing = userService.value
        if (existing != null && existing.asBinder().isBinderAlive) {
            return existing
        }
        if (getStatus() != ShizukuStatus.GRANTED) return null

        runCatching {
            Shizuku.bindUserService(userServiceArgs, serviceConnection)
        }
        return withTimeoutOrNull(4_000L) {
            userService.filterNotNull().first()
        }
    }

    suspend fun forceStopPackage(packageName: String): Boolean = withContext(Dispatchers.IO) {
        if (getStatus() != ShizukuStatus.GRANTED) return@withContext false
        val service = getOrBindUserService() ?: return@withContext false
        try {
            service.forceStopPackage(packageName)
        } catch (_: Exception) {
            false
        }
    }
}
