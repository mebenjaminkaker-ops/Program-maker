package com.example.data.system

import android.content.Context
import androidx.annotation.Keep
import com.example.IShizukuTaskService
import kotlin.system.exitProcess

@Keep
class ShizukuTaskService @Keep constructor(
    @Suppress("UNUSED_PARAMETER") context: Context? = null,
) : IShizukuTaskService.Stub() {

    override fun forceStopPackage(packageName: String): Boolean {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("am", "force-stop", packageName))
            val exitCode = process.waitFor()
            process.destroy()
            exitCode == 0
        } catch (_: Exception) {
            false
        }
    }

    override fun destroy() {
        exitProcess(0)
    }
}
