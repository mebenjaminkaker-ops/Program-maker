package com.example;

interface IShizukuTaskService {
    void destroy() = 16777114;
    boolean forceStopPackage(String packageName) = 1;
}
