package com.example

import com.example.data.local.CleanupLogDao
import com.example.data.local.CleanupLogEntity
import com.example.data.local.CleanupRepository
import com.example.util.PersianUtils
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun `persian digits and byte formatting are accurate`() {
        assertEquals("۱۲۳۴۵", PersianUtils.toPersianDigits("12345"))
        assertEquals("۴۵۰ MB", PersianUtils.formatBytesShort(450L * 1024L * 1024L))
        assertEquals("۱۲۰ مگابایت", PersianUtils.formatBytesPersianWords(120L * 1024L * 1024L))
    }

    @Test
    fun `gregorian to jalali conversion is accurate`() {
        val (jy, jm, jd) = PersianUtils.gregorianToJalali(2026, 3, 21)
        assertEquals(1405, jy)
        assertEquals(1, jm)
        assertEquals(1, jd)
    }

    @Test
    fun `cleanup repository records and sums logs`() = runBlocking {
        val fakeDao = object : CleanupLogDao {
            private val items = MutableStateFlow<List<CleanupLogEntity>>(emptyList())

            override fun getAllLogs(): Flow<List<CleanupLogEntity>> = items

            override fun getTotalFreedBytes(): Flow<Long?> =
                items.map { list -> list.sumOf { it.freedBytes } }

            override suspend fun insertLog(log: CleanupLogEntity) {
                items.value = listOf(log.copy(id = (items.value.size + 1).toLong())) + items.value
            }

            override suspend fun clearAll() {
                items.value = emptyList()
            }
        }

        val repository = CleanupRepository(fakeDao)
        repository.recordCleanup(
            description = "پاکسازی فایل‌های موقت",
            freedBytes = 120L * 1024L * 1024L,
            filesDeletedCount = 4,
            isSensitiveCleanup = false,
        )
        repository.recordCleanup(
            description = "پاکسازی عکس‌های تکراری",
            freedBytes = 80L * 1024L * 1024L,
            filesDeletedCount = 2,
            isSensitiveCleanup = true,
        )

        val logs = repository.allLogs.first()
        val total = repository.totalFreedBytes.first()
        assertEquals(2, logs.size)
        assertEquals(200L * 1024L * 1024L, total)
        assertTrue(logs.any { it.accentType == 1 })
    }
}
